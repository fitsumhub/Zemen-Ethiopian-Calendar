import 'package:cupertino_ui/cupertino_ui.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/calendar/ethiopian_calendar_engine.dart';
import '../../core/calendar/ethiopian_date.dart';
import '../../core/calendar/gregorian_date.dart';
import '../../core/localization/locale_strings.dart';
import '../../core/theme/app_colors.dart';
import '../shared/providers.dart';
import 'tabs/age_difference_tab.dart';
import 'tabs/bahire_hasab_tab.dart';
import 'tabs/geez_numerals_tab.dart';
import 'tabs/time_converter_tab.dart';

const _gregMonths = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

/// Converter: [Convert | Age | Date Math] on unified dark canvas.
/// Select Date card, wheel pickers, RESULT card — AppColors.
class ConverterHomeScreen extends ConsumerStatefulWidget {
  final ValueChanged<EthiopianDate>? onNavigateToCalendar;

  const ConverterHomeScreen({super.key, this.onNavigateToCalendar});

  @override
  ConsumerState<ConverterHomeScreen> createState() =>
      _ConverterHomeScreenState();
}

class _ConverterHomeScreenState extends ConsumerState<ConverterHomeScreen> {
  int _mode = 0; // 0 Convert, 1 Age, 2 Date Math
  bool _isEthiopian = true;

  late FixedExtentScrollController _monthCtrl;
  late FixedExtentScrollController _dayCtrl;
  late FixedExtentScrollController _yearCtrl;

  int _ethMonth = 3;
  int _ethDay = 6;
  int _ethYear = 2019;
  int _gregMonth = 11;
  int _gregDay = 15;
  int _gregYear = 2026;

  @override
  void initState() {
    super.initState();
    final eth = EthiopianCalendarEngine.todayEthiopian();
    final greg = EthiopianCalendarEngine.todayGregorian();
    _ethMonth = eth.month;
    _ethDay = eth.day;
    _ethYear = eth.year;
    _gregMonth = greg.month;
    _gregDay = greg.day;
    _gregYear = greg.year;
    _monthCtrl = FixedExtentScrollController(initialItem: _ethMonth - 1);
    _dayCtrl = FixedExtentScrollController(initialItem: _ethDay - 1);
    _yearCtrl = FixedExtentScrollController(initialItem: _ethYear - 1900);
  }

  @override
  void dispose() {
    _monthCtrl.dispose();
    _dayCtrl.dispose();
    _yearCtrl.dispose();
    super.dispose();
  }

  void _resetPickers() {
    _monthCtrl.dispose();
    _dayCtrl.dispose();
    _yearCtrl.dispose();
    if (_isEthiopian) {
      _monthCtrl = FixedExtentScrollController(initialItem: _ethMonth - 1);
      _dayCtrl = FixedExtentScrollController(initialItem: _ethDay - 1);
      _yearCtrl = FixedExtentScrollController(
          initialItem: (_ethYear - 1900).clamp(0, 200));
    } else {
      _monthCtrl = FixedExtentScrollController(initialItem: _gregMonth - 1);
      _dayCtrl = FixedExtentScrollController(initialItem: _gregDay - 1);
      _yearCtrl = FixedExtentScrollController(
          initialItem: (_gregYear - 1900).clamp(0, 200));
    }
  }

  void _setDirection(bool ethiopian) {
    if (_isEthiopian == ethiopian) return;
    setState(() {
      _isEthiopian = ethiopian;
      _clampSelectedDay();
      _resetPickers();
    });
  }

  /// Keeps day within the selected month (critical for Pagume 5/6 days).
  void _clampSelectedDay() {
    if (_isEthiopian) {
      final max = EthiopianDate.daysInMonthFor(_ethYear, _ethMonth);
      if (_ethDay > max) _ethDay = max;
    } else {
      final max = DateTime(_gregYear, _gregMonth + 1, 0).day;
      if (_gregDay > max) _gregDay = max;
    }
  }

  void _onMonthChanged(int index) {
    setState(() {
      if (_isEthiopian) {
        _ethMonth = index + 1;
      } else {
        _gregMonth = index + 1;
      }
      final before = _isEthiopian ? _ethDay : _gregDay;
      _clampSelectedDay();
      final after = _isEthiopian ? _ethDay : _gregDay;
      if (after != before && _dayCtrl.hasClients) {
        _dayCtrl.jumpToItem(after - 1);
      }
    });
  }

  void _onYearChanged(int index) {
    setState(() {
      if (_isEthiopian) {
        _ethYear = 1900 + index;
      } else {
        _gregYear = 1900 + index;
      }
      final before = _isEthiopian ? _ethDay : _gregDay;
      _clampSelectedDay();
      final after = _isEthiopian ? _ethDay : _gregDay;
      if (after != before && _dayCtrl.hasClients) {
        _dayCtrl.jumpToItem(after - 1);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(currentAppLanguageProvider);

    if (_mode == 1 || _mode == 2) {
      return ColoredBox(
        color: AppColors.canvas,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: _modeBar(),
            ),
            Expanded(
              child: AgeAndDifferenceTab(
                currentLang: lang,
                initialMode: _mode == 1 ? 0 : 1,
                hideModeSwitcher: true,
              ),
            ),
          ],
        ),
      );
    }

    if (_mode == 3) {
      return ColoredBox(
        color: AppColors.canvas,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: _modeBar(),
            ),
            Expanded(
              child: BahireHasabTab(currentLang: lang),
            ),
          ],
        ),
      );
    }

    if (_mode == 4) {
      return ColoredBox(
        color: AppColors.canvas,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: _modeBar(),
            ),
            Expanded(
              child: GeezNumeralsTab(),
            ),
          ],
        ),
      );
    }

    if (_mode == 5) {
      return ColoredBox(
        color: AppColors.canvas,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: _modeBar(),
            ),
            const Expanded(
              child: TimeConverterTab(),
            ),
          ],
        ),
      );
    }

    // Conversion logic — use clamped locals (state is clamped on picker change).
    var ethY = _ethYear;
    var ethM = _ethMonth;
    var ethD = _ethDay;
    var gregY = _gregYear;
    var gregM = _gregMonth;
    var gregD = _gregDay;

    final maxDays = _isEthiopian
        ? EthiopianDate.daysInMonthFor(ethY, ethM)
        : DateTime(gregY, gregM + 1, 0).day;
    if (_isEthiopian && ethD > maxDays) ethD = maxDays;
    if (!_isEthiopian && gregD > maxDays) gregD = maxDays;

    if (_isEthiopian) {
      final g = EthiopianCalendarEngine.toGregorian(
          EthiopianDate(ethY, ethM, ethD));
      gregY = g.year;
      gregM = g.month;
      gregD = g.day;
    } else {
      final e = EthiopianCalendarEngine.toEthiopian(
          GregorianDate(gregY, gregM, gregD));
      ethY = e.year;
      ethM = e.month;
      ethD = e.day;
    }

    final ethDate = EthiopianDate(ethY, ethM, ethD);
    final dow = EthiopianCalendarEngine.getDayOfWeek(ethDate);
    final weekday = LocaleStrings.weekdaysEnglishLong[dow - 1];

    final isToday = ethDate == EthiopianCalendarEngine.todayEthiopian();

    return ColoredBox(
      color: AppColors.canvas,
      child: Column(
        children: [
          Expanded(
            child: ListView(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 16),
              children: [
                // —— Mode Bar: [Convert | Age | Date Math] (Screenshot 7) ——
                _modeBar(),
                SizedBox(height: 16),

                // —— Select Date Card (Screenshot 7) ——
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.surfaceBorder),
                  ),
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Select Date',
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      SizedBox(height: 12),

                      // Ethiopian / Gregorian Toggle
                      Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppColors.surfaceElevated,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: EdgeInsets.all(2),
                        child: Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () => _setDirection(true),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: _isEthiopian
                                        ? AppColors.surfaceElevated
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(8),
                                    border: _isEthiopian
                                        ? Border.all(
                                            color: AppColors.accent
                                                .withValues(alpha: 0.35),
                                          )
                                        : null,
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Ethiopian',
                                    style: GoogleFonts.outfit(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: _isEthiopian
                                          ? AppColors.accent
                                          : AppColors.textSecondary,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: () => _setDirection(false),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: !_isEthiopian
                                        ? AppColors.surfaceElevated
                                        : Colors.transparent,
                                    borderRadius: BorderRadius.circular(8),
                                    border: !_isEthiopian
                                        ? Border.all(
                                            color: AppColors.accent
                                                .withValues(alpha: 0.35),
                                          )
                                        : null,
                                  ),
                                  alignment: Alignment.center,
                                  child: Text(
                                    'Gregorian',
                                    style: GoogleFonts.outfit(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: !_isEthiopian
                                          ? AppColors.accent
                                          : AppColors.textSecondary,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // 3-Wheel Scroll Date Picker (Screenshot 7)
                      SizedBox(
                        height: 180,
                        child: Row(
                          children: [
                            // Month Wheel
                            Expanded(
                              flex: 4,
                              child: CupertinoPicker.builder(
                                scrollController: _monthCtrl,
                                itemExtent: 38,
                                selectionOverlay: Container(
                                  decoration: BoxDecoration(
                                    border: Border.symmetric(
                                      horizontal: BorderSide(
                                        color: AppColors.surfaceBorder,
                                        width: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                onSelectedItemChanged: _onMonthChanged,
                                childCount: _isEthiopian ? 13 : 12,
                                itemBuilder: (context, i) {
                                  final name = _isEthiopian
                                      ? LocaleStrings
                                          .ethiopianMonthsEnglish[i]
                                      : _gregMonths[i];
                                  final isSel = i ==
                                      (_isEthiopian
                                          ? _ethMonth - 1
                                          : _gregMonth - 1);
                                  return Center(
                                    child: Text(
                                      name,
                                      style: GoogleFonts.outfit(
                                        fontSize: isSel ? 17 : 14,
                                        fontWeight: isSel
                                            ? FontWeight.w700
                                            : FontWeight.w500,
                                        color: isSel
                                            ? AppColors.textPrimary
                                            : AppColors.textSecondary,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),

                            // Day Wheel
                            Expanded(
                              flex: 2,
                              child: CupertinoPicker.builder(
                                scrollController: _dayCtrl,
                                itemExtent: 38,
                                selectionOverlay: Container(
                                  decoration: BoxDecoration(
                                    border: Border.symmetric(
                                      horizontal: BorderSide(
                                        color: AppColors.surfaceBorder,
                                        width: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                onSelectedItemChanged: (i) {
                                  setState(() {
                                    if (_isEthiopian) {
                                      _ethDay = i + 1;
                                    } else {
                                      _gregDay = i + 1;
                                    }
                                  });
                                },
                                childCount: maxDays,
                                itemBuilder: (context, i) {
                                  final isSel = i ==
                                      (_isEthiopian
                                          ? _ethDay - 1
                                          : _gregDay - 1);
                                  return Center(
                                    child: Text(
                                      '${i + 1}',
                                      style: GoogleFonts.outfit(
                                        fontSize: isSel ? 18 : 14,
                                        fontWeight: isSel
                                            ? FontWeight.w700
                                            : FontWeight.w500,
                                        color: isSel
                                            ? AppColors.textPrimary
                                            : AppColors.textSecondary,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),

                            // Year Wheel
                            Expanded(
                              flex: 3,
                              child: CupertinoPicker.builder(
                                scrollController: _yearCtrl,
                                itemExtent: 38,
                                selectionOverlay: Container(
                                  decoration: BoxDecoration(
                                    border: Border.symmetric(
                                      horizontal: BorderSide(
                                        color: AppColors.surfaceBorder,
                                        width: 1,
                                      ),
                                    ),
                                  ),
                                ),
                                onSelectedItemChanged: _onYearChanged,
                                childCount: 200,
                                itemBuilder: (context, i) {
                                  final y = 1900 + i;
                                  final isSel = y ==
                                      (_isEthiopian ? _ethYear : _gregYear);
                                  return Center(
                                    child: Text(
                                      '$y',
                                      style: GoogleFonts.outfit(
                                        fontSize: isSel ? 18 : 14,
                                        fontWeight: isSel
                                            ? FontWeight.w700
                                            : FontWeight.w500,
                                        color: isSel
                                            ? AppColors.textPrimary
                                            : AppColors.textSecondary,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 16),

                // —— RESULT Card (Screenshot 7) ——
                Container(
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.surfaceBorder),
                  ),
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'RESULT',
                        style: GoogleFonts.outfit(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: AppColors.accent,
                          letterSpacing: 1.2,
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        _isEthiopian
                            ? '$weekday, ${_gregMonths[gregM - 1]} $gregD  $gregY'
                            : '$weekday, ${LocaleStrings.ethiopianMonthsEnglish[ethM - 1]} $ethD  $ethY',
                        style: GoogleFonts.outfit(
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        isToday ? 'Today' : 'Converted Date',
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }

  Widget _modeBar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          color: AppColors.surfaceElevated,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.surfaceBorder),
        ),
        padding: const EdgeInsets.all(3),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _modePill(0, 'Convert (ቀን)'),
            _modePill(1, 'Age (ዕድሜ)'),
            _modePill(2, 'Math (ልዩነት)'),
            _modePill(3, 'Computus (ባሕረ ሐሳብ)'),
            _modePill(4, 'Ge\'ez (ግዕዝ)'),
            _modePill(5, 'Time (ሰዓት)'),
          ],
        ),
      ),
    );
  }

  Widget _modePill(int index, String label) {
    final isSel = _mode == index;
    return GestureDetector(
      onTap: () => setState(() => _mode = index),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 14),
        decoration: BoxDecoration(
          color: isSel
              ? AppColors.accent.withValues(alpha: 0.18)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
          border: isSel
              ? Border.all(
                  color: AppColors.accent.withValues(alpha: 0.45),
                )
              : null,
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: GoogleFonts.outfit(
            fontSize: 13,
            fontWeight: isSel ? FontWeight.w700 : FontWeight.w500,
            color: isSel ? AppColors.accent : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

