import 'package:flutter/foundation.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/calendar/ethiopian_calendar_engine.dart';
import '../../../core/localization/app_language.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/share_helper.dart';
import '../../../core/widgets/home_widget_engine.dart';
import '../../../core/widgets/home_widget_sync.dart';
import '../../../data/preferences/user_preferences_repository.dart';

/// Shows the redesigned, theme-aware EthioCal home-widget picker with live calendar payloads.
void showWidgetPickerSheet(BuildContext context, AppLanguage lang) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => WidgetPickerSheet(currentLanguage: lang),
  );
}

class WidgetManagementDialog extends StatelessWidget {
  final AppLanguage currentLanguage;
  const WidgetManagementDialog({super.key, required this.currentLanguage});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: WidgetPickerSheet(currentLanguage: currentLanguage),
    );
  }
}

class WidgetPickerSheet extends StatefulWidget {
  final AppLanguage currentLanguage;
  const WidgetPickerSheet({super.key, required this.currentLanguage});

  @override
  State<WidgetPickerSheet> createState() => _WidgetPickerSheetState();
}

class _WidgetPickerSheetState extends State<WidgetPickerSheet> {
  int _selected = 0;
  bool _busy = false;
  bool _pinned = false;
  bool _showFasting = true;
  bool _showGeez = true;
  bool _showSaint = true;
  String _size = 'compact';
  DateTime _refreshedAt = DateTime.now();

  // Date sandbox stepping
  int _dayOffset = 0;
  bool _previewDark = true;

  late HomeWidgetSnapshot _basic;
  late HomeWidgetSnapshot _classic;
  late HomeWidgetSnapshot _prophets;
  late HomeWidgetSnapshot _genna;

  @override
  void initState() {
    super.initState();
    try {
      _selected =
          UserPreferencesRepository.instance.getWidgetStyle().clamp(0, 3);
    } catch (_) {
      _selected = 0;
    }
    _rebuildSnapshots();
    _loadOptions();
    _checkPinned();
    _syncSilent();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _previewDark = Theme.of(context).brightness == Brightness.dark;
  }

  Future<void> _loadOptions() async {
    final opts = await HomeWidgetSync.loadOptions();
    if (!mounted) return;
    setState(() {
      _showFasting = opts['showFasting'] as bool;
      _showGeez = opts['showGeez'] as bool;
      _showSaint = opts['showSaint'] as bool;
      _size = opts['size'] as String;
    });
  }

  void _rebuildSnapshots() {
    final lang = widget.currentLanguage;
    final today = EthiopianCalendarEngine.todayEthiopian();
    final targetDate = _dayOffset == 0
        ? today
        : HomeWidgetEngine.shiftDays(today, _dayOffset);

    _basic = HomeWidgetEngine.build(
      HomeWidgetKind.basicDate,
      lang: lang,
      forDate: targetDate,
    );
    _classic = HomeWidgetEngine.build(
      HomeWidgetKind.classicDate,
      lang: lang,
      forDate: targetDate,
    );
    _prophets = HomeWidgetEngine.build(
      HomeWidgetKind.prophetsFast,
      lang: lang,
      forDate: targetDate,
    );
    _genna = HomeWidgetEngine.build(
      HomeWidgetKind.nativityCountdown,
      lang: lang,
      forDate: targetDate,
    );
    _refreshedAt = DateTime.now();
  }

  HomeWidgetSnapshot get _active {
    switch (_selected) {
      case 1:
        return _classic;
      case 2:
        return _prophets;
      case 3:
        return _genna;
      default:
        return _basic;
    }
  }

  Future<void> _syncSilent() async {
    await HomeWidgetSync.sync(
      styleIndex: _selected,
      lang: widget.currentLanguage,
      showFasting: _showFasting,
      showGeez: _showGeez,
      showSaint: _showSaint,
      size: _size,
    );
  }

  Future<void> _checkPinned() async {
    final pinned = await HomeWidgetSync.areWidgetsPinned();
    if (mounted) setState(() => _pinned = pinned);
  }

  Future<void> _persist(int index) async {
    HapticFeedback.selectionClick();
    setState(() => _selected = index);
    try {
      await UserPreferencesRepository.instance.setWidgetStyle(index);
    } catch (_) {}
    await _syncSilent();
  }

  Future<void> _toggleOption({
    bool? fasting,
    bool? geez,
    bool? saint,
    String? size,
  }) async {
    HapticFeedback.selectionClick();
    setState(() {
      if (fasting != null) _showFasting = fasting;
      if (geez != null) _showGeez = geez;
      if (saint != null) _showSaint = saint;
      if (size != null) _size = size;
    });
    await _syncSilent();
  }

  void _stepDate(int delta) {
    HapticFeedback.selectionClick();
    setState(() {
      _dayOffset += delta;
      _rebuildSnapshots();
    });
  }

  void _resetDate() {
    HapticFeedback.mediumImpact();
    setState(() {
      _dayOffset = 0;
      _rebuildSnapshots();
    });
  }

  Future<void> _refresh() async {
    HapticFeedback.selectionClick();
    setState(() {
      _busy = true;
      _rebuildSnapshots();
    });
    await _syncSilent();
    await _checkPinned();
    if (!mounted) return;
    setState(() => _busy = false);
    _toast('ተዘምኗል · ${_active.monthName} ${_active.eth.day}');
  }

  Future<void> _share() async {
    ShareHelper.share(
      HomeWidgetEngine.shareText(_active, lang: widget.currentLanguage),
      subject: 'Zemen: Ethiopian Calendar · Widget',
    );
  }

  Future<void> _copy() async {
    await Clipboard.setData(
      ClipboardData(
        text: HomeWidgetEngine.shareText(
          _active,
          lang: widget.currentLanguage,
        ),
      ),
    );
    if (!mounted) return;
    _toast('ወደ ቅንጥብ ተቀድቷል');
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: GoogleFonts.outfit()),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _addToHome() async {
    HapticFeedback.mediumImpact();
    setState(() => _busy = true);
    await _syncSilent();
    final status = await HomeWidgetSync.requestPin();
    await _checkPinned();
    if (!mounted) return;
    setState(() => _busy = false);

    final message = switch (status) {
      'pin_requested' =>
        'Pin dialog opened — confirm to place the live EthioCal widget.',
      'legacy_manual' || 'unsupported' =>
        'Style saved. Long-press home → Widgets → Zemen: Ethiopian Calendar.',
      'web_preview' =>
        'Live widget style saved. Pin it from an Android build.',
      'pin_failed' =>
        'Could not open pin dialog. Add Zemen: Ethiopian Calendar from Widgets.',
      _ => 'Widget style saved and synced.',
    };

    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: GoogleFonts.outfit()),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 4),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final s = _active;

    final sheetBg = isDark ? AppColors.darkCard : Colors.white;
    final sheetBorder = isDark ? AppColors.darkBorder : Color(0xFFE2E8F0);
    final textHigh = isDark ? AppColors.darkTextHigh : Color(0xFF0F172A);
    final textMed = isDark ? AppColors.darkTextMed : Color(0xFF64748B);
    final accent = AppColors.accent;

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.94,
      ),
      decoration: BoxDecoration(
        color: sheetBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border.all(color: sheetBorder, width: 1),
      ),
      padding: EdgeInsets.fromLTRB(16, 12, 16, 16 + bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Handle Bar
            Center(
              child: Container(
                width: 44,
                height: 4.5,
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF475569) : const Color(0xFFCBD5E1),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Sheet Title & Actions Row
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'የስልክ ዊጄት ምርጫ (Widget Studio)',
                        style: GoogleFonts.outfit(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: textHigh,
                          letterSpacing: -0.3,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Live · ${_fmtTime(_refreshedAt)}'
                        '${_pinned ? ' · pinned' : ''}'
                        '${kIsWeb ? ' · preview' : ''}',
                        style: GoogleFonts.outfit(
                          fontSize: 12,
                          color: textMed,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

                // Theme Mode Preview Toggle (Dark/Light preview)
                _ThemedIconChip(
                  icon: _previewDark
                      ? Icons.dark_mode_rounded
                      : Icons.light_mode_rounded,
                  tooltip: _previewDark ? 'Dark Preview' : 'Light Preview',
                  onTap: () {
                    setState(() => _previewDark = !_previewDark);
                  },
                ),
                const SizedBox(width: 6),
                _ThemedIconChip(
                  icon: Icons.refresh_rounded,
                  tooltip: 'አድስ (Refresh)',
                  onTap: _busy ? null : _refresh,
                  busy: _busy,
                ),
                const SizedBox(width: 6),
                _ThemedIconChip(
                  icon: Icons.copy_rounded,
                  tooltip: 'ቅዳ (Copy)',
                  onTap: _copy,
                ),
                const SizedBox(width: 6),
                _ThemedIconChip(
                  icon: Icons.ios_share_rounded,
                  tooltip: 'አጋራ (Share)',
                  onTap: _share,
                ),
              ],
            ),
            SizedBox(height: 14),

            // Date Sandbox Stepper: Test widget across different dates!
            Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: isDark
                    ? AppColors.darkCardElevated.withValues(alpha: 0.6)
                    : const Color(0xFFF1F5F9),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: sheetBorder),
              ),
              child: Row(
                children: [
                  Icon(Icons.calendar_month_rounded, size: 16, color: accent),
                  const SizedBox(width: 8),
                  Text(
                    'የቀን ቅድመ-ዕይታ (Preview Date):',
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: textMed,
                    ),
                  ),
                  const Spacer(),
                  _MiniStepButton(
                    icon: Icons.chevron_left_rounded,
                    onTap: () => _stepDate(-1),
                  ),
                  const SizedBox(width: 4),
                  InkWell(
                    onTap: _dayOffset != 0 ? _resetDate : null,
                    borderRadius: BorderRadius.circular(6),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      child: Text(
                        _dayOffset == 0
                            ? 'ዛሬ (Today)'
                            : _dayOffset == -1
                                ? 'ትላንት (-1)'
                                : _dayOffset == 1
                                    ? 'ነገ (+1)'
                                    : '$_dayOffset ቀናት',
                        style: GoogleFonts.outfit(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: _dayOffset == 0 ? textHigh : accent,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  _MiniStepButton(
                    icon: Icons.chevron_right_rounded,
                    onTap: () => _stepDate(1),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Active Selected Live Strip
            _SelectedLiveStrip(
              snapshot: s,
              styleIndex: _selected,
              showFasting: _showFasting,
              showGeez: _showGeez,
              showSaint: _showSaint,
              previewDark: _previewDark,
            ),
            const SizedBox(height: 16),

            // 4 Preset Cards Grid (2x2)
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.88,
              children: [
                _WidgetCard(
                  selected: _selected == 0,
                  onTap: () => _persist(0),
                  label: 'ዘመናዊ (Modern)',
                  previewDark: _previewDark,
                  child: _BasicDatePreview(
                    snapshot: _basic,
                    showGeez: _showGeez,
                    showFasting: _showFasting,
                    previewDark: _previewDark,
                  ),
                ),
                _WidgetCard(
                  selected: _selected == 1,
                  onTap: () => _persist(1),
                  label: 'ባህላዊ (Classic)',
                  previewDark: _previewDark,
                  child: _ClassicDatePreview(
                    snapshot: _classic,
                    showGeez: _showGeez,
                    showFasting: _showFasting,
                    previewDark: _previewDark,
                  ),
                ),
                _WidgetCard(
                  selected: _selected == 2,
                  onTap: () => _persist(2),
                  label: 'ጾመ ነቢያት (Prophets)',
                  previewDark: _previewDark,
                  child: _FastOfProphetsPreview(
                    snapshot: _prophets,
                    previewDark: _previewDark,
                  ),
                ),
                _WidgetCard(
                  selected: _selected == 3,
                  onTap: () => _persist(3),
                  label: 'ገና ቆጣሪ (Nativity)',
                  previewDark: _previewDark,
                  child: _NativityCountdownPreview(
                    snapshot: _genna,
                    previewDark: _previewDark,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Size Options (Compact vs Wide)
            Row(
              children: [
                Expanded(
                  child: _SizeChip(
                    label: 'Compact (2×2)',
                    subtitle: 'አነስተኛ ካሬ',
                    selected: _size == 'compact',
                    onTap: () => _toggleOption(size: 'compact'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _SizeChip(
                    label: 'Wide (4×2)',
                    subtitle: 'ሰፊ ባነር',
                    selected: _size == 'wide',
                    onTap: () => _toggleOption(size: 'wide'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Feature Filter Chips (Fasting, Geez, Saint)
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _OptionChip(
                  label: 'ጾም (Fasting)',
                  icon: Icons.spa_rounded,
                  selected: _showFasting,
                  onTap: () => _toggleOption(fasting: !_showFasting),
                ),
                _OptionChip(
                  label: 'ግዕዝ (Ge\'ez)',
                  icon: Icons.translate_rounded,
                  selected: _showGeez,
                  onTap: () => _toggleOption(geez: !_showGeez),
                ),
                _OptionChip(
                  label: 'ጽላት / ቅዱስ (Saint)',
                  icon: Icons.auto_awesome_rounded,
                  selected: _showSaint,
                  onTap: () => _toggleOption(saint: !_showSaint),
                ),
              ],
            ),
            const SizedBox(height: 18),

            // Add to Home Screen Action CTA
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: accent.withValues(alpha: 0.5),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                icon: const Icon(Icons.add_to_home_screen_rounded, size: 20),
                onPressed: _busy ? null : _addToHome,
                label: Text(
                  kIsWeb ? 'Save Widget Style' : 'ወደ ስልክ ማያ ጨምር (Add to Home)',
                  style: GoogleFonts.outfit(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static String _fmtTime(DateTime t) {
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}

// ---------------------------------------------------------------------------
// MINI HELPERS & CHIPS
// ---------------------------------------------------------------------------

class _ThemedIconChip extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  final bool busy;

  const _ThemedIconChip({
    required this.icon,
    required this.tooltip,
    this.onTap,
    this.busy = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Material(
      color: isDark ? AppColors.darkCardElevated : Color(0xFFF1F5F9),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Tooltip(
          message: tooltip,
          child: SizedBox(
            width: 38,
            height: 38,
            child: Center(
              child: busy
                  ? SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(
                      icon,
                      size: 18,
                      color: isDark ? AppColors.darkTextHigh : Color(0xFF334155),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MiniStepButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _MiniStepButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Material(
      color: isDark ? AppColors.darkCard : Colors.white,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: EdgeInsets.all(4),
          child: Icon(
            icon,
            size: 18,
            color: isDark ? AppColors.darkTextHigh : Color(0xFF334155),
          ),
        ),
      ),
    );
  }
}

class _SizeChip extends StatelessWidget {
  final String label;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  const _SizeChip({
    required this.label,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final accent = AppColors.accent;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 180),
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          color: selected
              ? accent.withValues(alpha: 0.12)
              : (isDark ? AppColors.darkCardElevated : Color(0xFFF8FAFC)),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? accent : (isDark ? AppColors.darkBorder : Color(0xFFE2E8F0)),
            width: selected ? 1.6 : 1,
          ),
        ),
        alignment: Alignment.center,
        child: Column(
          children: [
            Text(
              label,
              style: GoogleFonts.outfit(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: selected ? accent : (isDark ? AppColors.darkTextHigh : Color(0xFF0F172A)),
              ),
            ),
            SizedBox(height: 2),
            Text(
              subtitle,
              style: GoogleFonts.outfit(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: isDark ? AppColors.darkTextMed : Color(0xFF64748B),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OptionChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _OptionChip({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final accent = AppColors.accent;

    return FilterChip(
      selected: selected,
      onSelected: (_) => onTap(),
      avatar: Icon(
        icon,
        size: 15,
        color: selected ? Colors.white : accent,
      ),
      label: Text(
        label,
        style: GoogleFonts.outfit(
          fontWeight: FontWeight.w700,
          fontSize: 12,
          color: selected ? Colors.white : (isDark ? AppColors.darkTextHigh : Color(0xFF0F172A)),
        ),
      ),
      selectedColor: accent,
      backgroundColor: isDark ? AppColors.darkCardElevated : Color(0xFFF1F5F9),
      checkmarkColor: Colors.white,
      side: BorderSide(
        color: selected ? accent : (isDark ? AppColors.darkBorder : Color(0xFFE2E8F0)),
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
    );
  }
}

// ---------------------------------------------------------------------------
// SELECTED LIVE STRIP
// ---------------------------------------------------------------------------

class _SelectedLiveStrip extends StatelessWidget {
  final HomeWidgetSnapshot snapshot;
  final int styleIndex;
  final bool showFasting;
  final bool showGeez;
  final bool showSaint;
  final bool previewDark;

  const _SelectedLiveStrip({
    required this.snapshot,
    required this.styleIndex,
    required this.showFasting,
    required this.showGeez,
    required this.showSaint,
    required this.previewDark,
  });

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.accent;
    final styleTitle = switch (styleIndex) {
      1 => 'ባህላዊ (Classic Heritage)',
      2 => 'ጾመ ነቢያት (Prophets Fast Tracker)',
      3 => 'ገና ቆጣሪ (Nativity Countdown)',
      _ => 'ዘመናዊ (Modern Dual Date)',
    };

    String detail;
    double? progress;
    switch (styleIndex) {
      case 2:
        if (snapshot.prophetsDayIndex != null && snapshot.prophetsDayIndex! > 0) {
          detail = 'ጾመ ነቢያት · ቀን ${snapshot.prophetsDayIndex}/${snapshot.prophetsTotalDays}';
          progress = snapshot.prophetsProgress;
        } else {
          detail = 'ጾመ ነቢያት በ ${snapshot.daysUntilAdvent ?? 0} ቀን ይጀምራል';
          progress = 0;
        }
      case 3:
        detail = 'ገና · ${snapshot.daysUntilGenna ?? 0} ቀን ቀረ (${snapshot.gennaLabel})';
        progress = snapshot.gennaSeasonProgress;
      default:
        detail = showSaint
            ? 'ጽላት · ${snapshot.saintName}'
            : 'Gregorian: ${snapshot.gregLabel}';
        progress = null;
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: previewDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: previewDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
          width: 1.2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                styleTitle,
                style: GoogleFonts.outfit(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: accent,
                ),
              ),
              const Spacer(),
              if (showFasting)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: snapshot.isFasting
                        ? const Color(0xFF059669).withValues(alpha: 0.15)
                        : (previewDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0)),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    snapshot.isFasting ? '🌿 ጾም' : '🍽️ ፍስክ',
                    style: GoogleFonts.outfit(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: snapshot.isFasting
                          ? const Color(0xFF10B981)
                          : (previewDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B)),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            '${snapshot.weekdayName} · ${snapshot.monthName} ${snapshot.eth.day}'
            '${showGeez ? ' (${snapshot.geezDay})' : ''} · ${snapshot.eth.year} ዓ.ም',
            style: GoogleFonts.outfit(
              fontSize: 15,
              fontWeight: FontWeight.w800,
              color: previewDark ? Colors.white : const Color(0xFF0F172A),
              letterSpacing: -0.2,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            detail,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.outfit(
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              color: previewDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
            ),
          ),
          if (progress != null) ...[
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 5,
                backgroundColor: previewDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
                color: accent,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// WIDGET CARD WRAPPER
// ---------------------------------------------------------------------------

class _WidgetCard extends StatelessWidget {
  final bool selected;
  final VoidCallback onTap;
  final String label;
  final Widget child;
  final bool previewDark;

  const _WidgetCard({
    required this.selected,
    required this.onTap,
    required this.label,
    required this.child,
    required this.previewDark,
  });

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.accent;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Column(
        children: [
          Expanded(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: double.infinity,
              decoration: BoxDecoration(
                color: previewDark ? const Color(0xFF1E293B) : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: selected
                      ? accent
                      : (previewDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0)),
                  width: selected ? 2.2 : 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: selected
                        ? accent.withValues(alpha: 0.22)
                        : const Color(0x0A000000),
                    blurRadius: selected ? 12 : 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              clipBehavior: Clip.antiAlias,
              child: child,
            ),
          ),
          SizedBox(height: 6),
          Text(
            label,
            style: GoogleFonts.outfit(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: selected
                  ? accent
                  : (previewDark ? AppColors.darkTextHigh : Color(0xFF0F172A)),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// 4 POLISHED PRESET IMPLEMENTATIONS
// ---------------------------------------------------------------------------

class _BasicDatePreview extends StatelessWidget {
  final HomeWidgetSnapshot snapshot;
  final bool showGeez;
  final bool showFasting;
  final bool previewDark;

  const _BasicDatePreview({
    required this.snapshot,
    required this.showGeez,
    required this.showFasting,
    required this.previewDark,
  });

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.accent;
    final textHigh = previewDark ? Colors.white : const Color(0xFF0F172A);
    final textMed = previewDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  snapshot.weekdayName,
                  style: GoogleFonts.outfit(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: accent,
                  ),
                ),
              ),
              const Spacer(),
              if (showFasting)
                Icon(
                  snapshot.isFasting ? Icons.spa_rounded : Icons.restaurant_rounded,
                  size: 13,
                  color: snapshot.isFasting
                      ? const Color(0xFF10B981)
                      : textMed,
                ),
            ],
          ),
          const Spacer(),
          Row(
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                '${snapshot.eth.day}',
                style: GoogleFonts.outfit(
                  fontSize: 38,
                  fontWeight: FontWeight.w800,
                  color: textHigh,
                  height: 1.0,
                ),
              ),
              const SizedBox(width: 6),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    snapshot.monthName,
                    style: GoogleFonts.outfit(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                      color: textHigh,
                    ),
                  ),
                  Text(
                    showGeez
                        ? '${snapshot.eth.year} · ${snapshot.geezDay}'
                        : '${snapshot.eth.year} ዓ.ም',
                    style: GoogleFonts.outfit(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w600,
                      color: textMed,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.only(top: 4),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: previewDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
                ),
              ),
            ),
            child: Text(
              snapshot.gregLabel,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.outfit(
                fontSize: 10.5,
                fontWeight: FontWeight.w500,
                color: textMed,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ClassicDatePreview extends StatelessWidget {
  final HomeWidgetSnapshot snapshot;
  final bool showGeez;
  final bool showFasting;
  final bool previewDark;

  const _ClassicDatePreview({
    required this.snapshot,
    required this.showGeez,
    required this.showFasting,
    required this.previewDark,
  });

  @override
  Widget build(BuildContext context) {
    final textHigh = previewDark ? Colors.white : const Color(0xFF0F172A);
    final textMed = previewDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Column(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 6),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFDC2626), Color(0xFFEF4444)],
            ),
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                snapshot.weekdayName,
                style: GoogleFonts.outfit(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
              if (showFasting) ...[
                const SizedBox(width: 5),
                Icon(
                  snapshot.isFasting ? Icons.spa_rounded : Icons.restaurant_rounded,
                  size: 11,
                  color: Colors.white.withValues(alpha: 0.9),
                ),
              ],
            ],
          ),
        ),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                snapshot.monthName,
                style: GoogleFonts.outfit(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: textHigh,
                ),
              ),
              Text(
                '${snapshot.eth.day}',
                style: GoogleFonts.outfit(
                  fontSize: 38,
                  fontWeight: FontWeight.w800,
                  color: textHigh,
                  height: 1.0,
                ),
              ),
              Text(
                showGeez
                    ? '${snapshot.geezDay} · ${snapshot.eth.year}'
                    : '${snapshot.eth.year} ዓ.ም',
                style: GoogleFonts.outfit(
                  fontSize: 10.5,
                  color: textMed,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _FastOfProphetsPreview extends StatelessWidget {
  final HomeWidgetSnapshot snapshot;
  final bool previewDark;

  const _FastOfProphetsPreview({
    required this.snapshot,
    required this.previewDark,
  });

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.accent;
    final textHigh = previewDark ? Colors.white : const Color(0xFF0F172A);
    final textMed = previewDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    final active =
        snapshot.prophetsDayIndex != null && snapshot.prophetsDayIndex! > 0;
    final number = active
        ? '${snapshot.prophetsDayIndex}'
        : '${snapshot.daysUntilAdvent ?? 0}';
    final subtitle = active
        ? 'ከ${snapshot.prophetsTotalDays ?? 43} ቀን'
        : 'ቀን ይቀራል';

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  color: const Color(0xFF10B981).withValues(alpha: 0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.spa_rounded,
                  color: Color(0xFF10B981),
                  size: 14,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: accent,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  'ጾም',
                  style: GoogleFonts.outfit(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            number,
            style: GoogleFonts.outfit(
              fontSize: 34,
              fontWeight: FontWeight.w800,
              color: textHigh,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: GoogleFonts.outfit(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: textMed,
            ),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: active ? snapshot.prophetsProgress : 0,
              minHeight: 4,
              backgroundColor: previewDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
              color: const Color(0xFF10B981),
            ),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}

class _NativityCountdownPreview extends StatelessWidget {
  final HomeWidgetSnapshot snapshot;
  final bool previewDark;

  const _NativityCountdownPreview({
    required this.snapshot,
    required this.previewDark,
  });

  @override
  Widget build(BuildContext context) {
    final accent = AppColors.accent;
    final textHigh = previewDark ? Colors.white : const Color(0xFF0F172A);
    final textMed = previewDark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.star_rounded, size: 16, color: accent),
              const SizedBox(width: 4),
              Text(
                'ገና ቆጣሪ',
                style: GoogleFonts.outfit(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: accent,
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(
            '${snapshot.daysUntilGenna ?? 0}',
            style: GoogleFonts.outfit(
              fontSize: 38,
              fontWeight: FontWeight.w800,
              color: textHigh,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'ቀናት ቀርተዋል',
            style: GoogleFonts.outfit(
              fontSize: 11.5,
              fontWeight: FontWeight.w500,
              color: textMed,
            ),
          ),
          const Spacer(),
          Text(
            snapshot.gennaLabel,
            style: GoogleFonts.outfit(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: textMed,
            ),
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: snapshot.gennaSeasonProgress,
              minHeight: 4,
              backgroundColor: previewDark ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
              color: accent,
            ),
          ),
        ],
      ),
    );
  }
}
