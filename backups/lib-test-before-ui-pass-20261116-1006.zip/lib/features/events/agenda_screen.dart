import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/calendar/ethiopian_calendar_engine.dart';
import '../../core/calendar/ethiopian_date.dart';
import '../../core/holidays/holiday_engine.dart';
import '../../core/localization/locale_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../data/models/event_entity.dart';
import '../shared/components/app_chrome.dart';
import '../shared/providers.dart';
import 'dialogs/add_edit_event_dialog.dart';

class _AgendaEntry {
  final EthiopianDate date;
  final String title;
  final String subtitle;
  final Color color;
  final EventEntity? event;
  final bool isHoliday;

  const _AgendaEntry({
    required this.date,
    required this.title,
    required this.subtitle,
    required this.color,
    this.event,
    this.isHoliday = false,
  });
}

/// Next 14 days: holidays + personal events, easy complete / edit / jump.
class AgendaScreen extends ConsumerWidget {
  final ValueChanged<EthiopianDate>? onOpenDate;

  const AgendaScreen({super.key, this.onOpenDate});

  EthiopianDate _shift(EthiopianDate d, int days) {
    return EthiopianCalendarEngine.jdnToEthiopian(
      EthiopianCalendarEngine.ethiopianToJdn(d) + days,
    );
  }

  Color _parseColor(String hex) {
    try {
      return Color(int.parse(hex.replaceFirst('#', '0xFF')));
    } catch (_) {
      return AppColors.accent;
    }
  }

  Future<void> _openEditor(
    BuildContext context,
    WidgetRef ref, {
    EthiopianDate? date,
    EventEntity? event,
  }) async {
    final lang = ref.read(currentAppLanguageProvider);
    final EthiopianDate initial = date ?? ref.read(todayEthiopianProvider);
    await AddEditEventDialog.open(
      context,
      initialDate: initial,
      eventToEdit: event,
      currentLanguage: lang,
      onSave: (saved) async {
        await ref.read(eventsNotifierProvider.notifier).saveEvent(saved);
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              event == null ? 'Event saved' : 'Event updated',
              style: GoogleFonts.outfit(),
            ),
            behavior: SnackBarBehavior.floating,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final today = ref.watch(todayEthiopianProvider);
    final lang = ref.watch(currentAppLanguageProvider);
    final events = ref.watch(eventsNotifierProvider).value ?? [];
    final holidays = [
      ...HolidayEngine.getHolidaysForYear(today.year),
      ...HolidayEngine.getHolidaysForYear(today.year + 1),
    ];

    final entries = <_AgendaEntry>[];
    for (var i = 0; i < 14; i++) {
      final date = _shift(today, i);
      final dayEvents = events.where((e) => eventMatchesDate(e, date)).toList()
        ..sort((a, b) {
          if (a.isAllDay != b.isAllDay) return a.isAllDay ? -1 : 1;
          final aMin = a.hour * 60 + a.minute;
          final bMin = b.hour * 60 + b.minute;
          return aMin.compareTo(bMin);
        });
      final dayHolidays = holidays.where(
        (h) =>
            h.ethiopianDate.year == date.year &&
            h.ethiopianDate.month == date.month &&
            h.ethiopianDate.day == date.day,
      );

      for (final h in dayHolidays) {
        entries.add(
          _AgendaEntry(
            date: date,
            title: h.titleEnglish,
            subtitle: h.titleAmharic,
            color: AppColors.accent,
            isHoliday: true,
          ),
        );
      }
      for (final e in dayEvents) {
        entries.add(
          _AgendaEntry(
            date: date,
            title: e.title,
            subtitle: e.isAllDay
                ? 'All day${e.description.isNotEmpty ? ' · ${e.description}' : ''}'
                : '${e.hour.toString().padLeft(2, '0')}:${e.minute.toString().padLeft(2, '0')}'
                    '${e.description.isNotEmpty ? ' · ${e.description}' : ''}',
            color: _parseColor(e.colorHex),
            event: e,
          ),
        );
      }
    }

    return Scaffold(
      backgroundColor: AppColors.canvas,
      floatingActionButton: AppPressable(
        onTap: () => _openEditor(context, ref, date: today),
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF5A5A), Color(0xFFEB2D2D)],
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFEB2D2D).withValues(alpha: 0.4),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text(
              'Next 14 days',
              style: GoogleFonts.outfit(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: const Color(0xFF8B93A3),
                letterSpacing: 0.3,
              ),
            ),
          ),
          Expanded(
            child: entries.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(32),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              color: const Color(0xFF171A21),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: const Color(0xFF2A2F3A)),
                            ),
                            child: const Icon(
                              Icons.event_available_rounded,
                              size: 34,
                              color: Color(0xFF6B7385),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Nothing coming up',
                            style: GoogleFonts.outfit(
                              fontSize: 17,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 6),
                          Text(
                            'Holidays and your events for the next two weeks appear here',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.outfit(
                              fontSize: 13,
                              color: Color(0xFF8B93A3),
                            ),
                          ),
                          SizedBox(height: 18),
                          FilledButton.icon(
                            onPressed: () => _openEditor(context, ref, date: today),
                            style: FilledButton.styleFrom(
                              backgroundColor: AppColors.accent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            icon: const Icon(Icons.add_rounded),
                            label: Text(
                              'Add event',
                              style: GoogleFonts.outfit(fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: entries.length,
                    itemBuilder: (context, i) {
                      final entry = entries[i];
                      final showHeader = i == 0 ||
                          entries[i - 1].date.year != entry.date.year ||
                          entries[i - 1].date.month != entry.date.month ||
                          entries[i - 1].date.day != entry.date.day;
                      final month =
                          LocaleStrings.getMonthName(entry.date.month, lang);
                      final dow = LocaleStrings.weekdaysEnglishLong[
                          EthiopianCalendarEngine.getDayOfWeek(entry.date) - 1];
                      final isToday = entry.date == today;

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (showHeader)
                            Padding(
                              padding: EdgeInsets.only(top: i == 0 ? 0 : 16, bottom: 8),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Row(
                                      children: [
                                        Text(
                                          isToday
                                              ? 'Today'
                                              : '$dow · $month ${entry.date.day}',
                                          style: GoogleFonts.outfit(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w700,
                                            color: isToday
                                                ? const Color(0xFFFF6B6B)
                                                : const Color(0xFF8B93A3),
                                          ),
                                        ),
                                        if (isToday) ...[
                                          const SizedBox(width: 8),
                                          Text(
                                            '$dow · $month ${entry.date.day}',
                                            style: GoogleFonts.outfit(
                                              fontSize: 12,
                                              color: const Color(0xFF6B7385),
                                            ),
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),
                                  AppPressable(
                                    onTap: () => _openEditor(
                                      context,
                                      ref,
                                      date: entry.date,
                                    ),
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: 30,
                                      height: 30,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF171A21),
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(color: const Color(0xFF2A2F3A)),
                                      ),
                                      child: const Icon(
                                        Icons.add_rounded,
                                        size: 18,
                                        color: Color(0xFFB8C0D0),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          AppPressable(
                            onTap: () {
                              if (entry.event != null) {
                                _openEditor(
                                  context,
                                  ref,
                                  date: entry.date,
                                  event: entry.event,
                                );
                              } else {
                                onOpenDate?.call(entry.date);
                              }
                            },
                            borderRadius: BorderRadius.circular(14),
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF15181F),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: const Color(0xFF262B36)),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.fromLTRB(12, 4, 8, 4),
                                leading: Container(
                                  width: 4,
                                  height: 42,
                                  decoration: BoxDecoration(
                                    color: entry.color,
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                ),
                                title: Row(
                                  children: [
                                    if (entry.isHoliday) ...[
                                      const Icon(
                                        Icons.celebration_rounded,
                                        size: 14,
                                        color: Color(0xFFFF6B6B),
                                      ),
                                      const SizedBox(width: 6),
                                    ],
                                    Expanded(
                                      child: Text(
                                        entry.title,
                                        style: GoogleFonts.outfit(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w700,
                                          color: Colors.white,
                                          decoration: entry.event?.isCompleted == true
                                              ? TextDecoration.lineThrough
                                              : null,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                subtitle: Text(
                                  entry.subtitle,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.outfit(
                                    fontSize: 12,
                                    color: const Color(0xFF8B93A3),
                                  ),
                                ),
                                trailing: entry.event == null
                                    ? const Icon(
                                        Icons.chevron_right_rounded,
                                        color: Color(0xFF6B7385),
                                        size: 22,
                                      )
                                    : IconButton(
                                        tooltip: entry.event!.isCompleted
                                            ? 'Mark incomplete'
                                            : 'Complete',
                                        icon: Icon(
                                          entry.event!.isCompleted
                                              ? Icons.check_circle_rounded
                                              : Icons.circle_outlined,
                                          color: entry.event!.isCompleted
                                              ? const Color(0xFF1FA87A)
                                              : const Color(0xFF6B7385),
                                        ),
                                        onPressed: () {
                                          ref
                                              .read(eventsNotifierProvider.notifier)
                                              .toggleEventCompletion(entry.event!);
                                        },
                                      ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
