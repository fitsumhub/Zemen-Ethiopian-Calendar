import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/export/ics_exporter.dart';
import '../../core/localization/locale_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/share_helper.dart';
import '../../data/models/event_entity.dart';
import '../shared/components/app_chrome.dart';
import '../shared/providers.dart';
import 'dialogs/add_edit_event_dialog.dart';

class EventsScreen extends ConsumerStatefulWidget {
  const EventsScreen({super.key});

  @override
  ConsumerState<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends ConsumerState<EventsScreen> {
  final TextEditingController _searchController = TextEditingController();

  static const _categories = [
    _Cat('ALL', 'All', Icons.apps_rounded),
    _Cat('TASK', 'Tasks', Icons.check_circle_outline_rounded),
    _Cat('MEETING', 'Meetings', Icons.groups_rounded),
    _Cat('BIRTHDAY', 'Birthdays', Icons.cake_rounded),
    _Cat('EXAM', 'Exams', Icons.school_rounded),
    _Cat('ANNIVERSARY', 'Anniversaries', Icons.favorite_border_rounded),
    _Cat('RELIGIOUS', 'Religious', Icons.temple_buddhist_rounded),
    _Cat('CULTURAL', 'Cultural', Icons.public_rounded),
    _Cat('OTHER', 'Other', Icons.more_horiz_rounded),
  ];

  Future<void> _showAddEditEventDialog([EventEntity? eventToEdit]) async {
    final todayEth = ref.read(todayEthiopianProvider);
    final currentLang = ref.read(currentAppLanguageProvider);
    await AddEditEventDialog.open(
      context,
      initialDate: todayEth,
      eventToEdit: eventToEdit,
      currentLanguage: currentLang,
      onSave: (event) async {
        await ref.read(eventsNotifierProvider.notifier).saveEvent(event);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              eventToEdit == null ? 'Event saved' : 'Event updated',
              style: GoogleFonts.outfit(),
            ),
            behavior: SnackBarBehavior.floating,
          ),
        );
      },
    );
  }

  Future<void> _confirmDelete(EventEntity event) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Color(0xFF1A1D26),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Delete event?', style: GoogleFonts.outfit(fontWeight: FontWeight.w700)),
        content: Text(
          '"${event.title}" will be removed.',
          style: GoogleFonts.outfit(color: AppColors.darkTextMed),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFC62828)),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true && mounted) {
      await ref.read(eventsNotifierProvider.notifier).deleteEvent(event.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Deleted "${event.title}"', style: GoogleFonts.outfit()),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _exportEventsToIcs(List<EventEntity> events) {
    if (events.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('No events to export', style: GoogleFonts.outfit()),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }
    final icsContent = IcsExporter.exportToIcs(events);
    ShareHelper.share(icsContent, subject: 'ethiocal_events.ics');
  }

  Color _parseColor(String hex) {
    try {
      return Color(int.parse(hex.replaceFirst('#', '0xFF')));
    } catch (_) {
      return AppColors.accent;
    }
  }

  String _recurrenceLabel(String r) {
    switch (r) {
      case 'DAILY':
        return 'Daily';
      case 'WEEKLY':
        return 'Weekly';
      case 'MONTHLY_ETHIOPIAN':
        return 'Monthly';
      case 'MONTHLY_GREGORIAN':
        return 'Monthly (G)';
      case 'YEARLY_ETHIOPIAN':
        return 'Yearly';
      case 'YEARLY_GREGORIAN':
        return 'Yearly (G)';
      default:
        return '';
    }
  }

  IconData _categoryIcon(String id) {
    return _categories
        .firstWhere((c) => c.id == id, orElse: () => _categories.last)
        .icon;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lang = ref.watch(currentAppLanguageProvider);
    final filtered = ref.watch(filteredEventsProvider);
    final allEvents = ref.watch(eventsNotifierProvider).value ?? [];
    final selectedCategory = ref.watch(eventCategoryFilterProvider);
    final selectedStatus = ref.watch(eventStatusFilterProvider);
    final openCount = allEvents.where((e) => !e.isCompleted).length;
    final doneCount = allEvents.where((e) => e.isCompleted).length;

    return Scaffold(
      backgroundColor: AppColors.canvas,
      floatingActionButton: AppPressable(
        onTap: () => _showAddEditEventDialog(),
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF5A5A), Color(0xFFEB2D2D)],
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFEB2D2D).withValues(alpha: 0.4),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
        ),
      ),
      body: Column(
        children: [
          // Header stats
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: _StatPill(
                    label: 'Open',
                    value: '$openCount',
                    color: const Color(0xFFFF6B6B),
                    selected: selectedStatus == 'OPEN',
                    onTap: () => ref.read(eventStatusFilterProvider.notifier).set(
                          selectedStatus == 'OPEN' ? 'ALL' : 'OPEN',
                        ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _StatPill(
                    label: 'Done',
                    value: '$doneCount',
                    color: const Color(0xFF1FA87A),
                    selected: selectedStatus == 'DONE',
                    onTap: () => ref.read(eventStatusFilterProvider.notifier).set(
                          selectedStatus == 'DONE' ? 'ALL' : 'DONE',
                        ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _StatPill(
                    label: 'Total',
                    value: '${allEvents.length}',
                    color: const Color(0xFF6CABDD),
                    selected: selectedStatus == 'ALL',
                    onTap: () => ref.read(eventStatusFilterProvider.notifier).set('ALL'),
                  ),
                ),
                const SizedBox(width: 8),
                AppPressable(
                  onTap: () => _exportEventsToIcs(allEvents),
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: const Color(0xFF171A21),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFF2A2F3A)),
                    ),
                    child: const Icon(Icons.ios_share_rounded, color: Color(0xFFB8C0D0), size: 20),
                  ),
                ),
              ],
            ),
          ),

          // Search
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _searchController,
              style: GoogleFonts.outfit(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: LocaleStrings.get('search_events', lang),
                hintStyle: GoogleFonts.outfit(color: const Color(0xFF7A8496)),
                prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF7A8496)),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear_rounded, color: Color(0xFF7A8496)),
                        onPressed: () {
                          _searchController.clear();
                          ref.read(eventSearchQueryProvider.notifier).set('');
                          setState(() {});
                        },
                      )
                    : null,
                filled: true,
                fillColor: const Color(0xFF171A21),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: Color(0xFF2A2F3A)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: Color(0xFF2A2F3A)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: Color(0xFFFF6B6B)),
                ),
              ),
              onChanged: (val) {
                ref.read(eventSearchQueryProvider.notifier).set(val);
                setState(() {});
              },
            ),
          ),
          const SizedBox(height: 10),

          // Category chips
          SizedBox(
            height: 40,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: _categories.length,
              separatorBuilder: (_, _) => const SizedBox(width: 8),
              itemBuilder: (context, i) {
                final cat = _categories[i];
                final selected = selectedCategory == cat.id;
                return AppPressable(
                  onTap: () => ref.read(eventCategoryFilterProvider.notifier).set(cat.id),
                  borderRadius: BorderRadius.circular(20),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: selected
                          ? const Color(0xFFFF6B6B).withValues(alpha: 0.18)
                          : const Color(0xFF171A21),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: selected ? const Color(0xFFFF6B6B) : const Color(0xFF2A2F3A),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          cat.icon,
                          size: 15,
                          color: selected ? const Color(0xFFFF8A80) : const Color(0xFF8B93A3),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          cat.label,
                          style: GoogleFonts.outfit(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: selected ? Colors.white : const Color(0xFF8B93A3),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),

          // List
          Expanded(
            child: filtered.isEmpty
                ? _EmptyEvents(
                    hasAny: allEvents.isNotEmpty,
                    onAdd: () => _showAddEditEventDialog(),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 6, 16, 96),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final event = filtered[index];
                      final color = _parseColor(event.colorHex);
                      final month = LocaleStrings.getMonthName(event.ethiopianMonth, lang);
                      final rec = _recurrenceLabel(event.recurrence);
                      final showDateHeader = index == 0 ||
                          filtered[index - 1].ethiopianYear != event.ethiopianYear ||
                          filtered[index - 1].ethiopianMonth != event.ethiopianMonth ||
                          filtered[index - 1].ethiopianDay != event.ethiopianDay;

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (showDateHeader)
                            Padding(
                              padding: EdgeInsets.only(
                                top: index == 0 ? 2 : 12,
                                bottom: 8,
                                left: 2,
                              ),
                              child: Text(
                                '$month ${event.ethiopianDay}, ${event.ethiopianYear}',
                                style: GoogleFonts.outfit(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: const Color(0xFF8B93A3),
                                  letterSpacing: 0.2,
                                ),
                              ),
                            ),
                          Dismissible(
                            key: ValueKey('ev_${event.id}'),
                            direction: DismissDirection.endToStart,
                            confirmDismiss: (_) async {
                              await _confirmDelete(event);
                              return false;
                            },
                            background: Container(
                              alignment: Alignment.centerRight,
                              padding: const EdgeInsets.only(right: 20),
                              margin: const EdgeInsets.only(bottom: 10),
                              decoration: BoxDecoration(
                                color: const Color(0xFFC62828),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: const Icon(Icons.delete_rounded, color: Colors.white),
                            ),
                            child: AppPressable(
                              onTap: () => _showAddEditEventDialog(event),
                              borderRadius: BorderRadius.circular(16),
                              child: Container(
                                margin: const EdgeInsets.only(bottom: 10),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF15181F),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: const Color(0xFF262B36)),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(alpha: 0.25),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: IntrinsicHeight(
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 5,
                                        decoration: BoxDecoration(
                                          color: color,
                                          borderRadius: const BorderRadius.horizontal(
                                            left: Radius.circular(16),
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.fromLTRB(10, 12, 8, 12),
                                          child: Row(
                                            children: [
                                              AppPressable(
                                                onTap: () => ref
                                                    .read(eventsNotifierProvider.notifier)
                                                    .toggleEventCompletion(event),
                                                borderRadius: BorderRadius.circular(20),
                                                child: Icon(
                                                  event.isCompleted
                                                      ? Icons.check_circle_rounded
                                                      : Icons.circle_outlined,
                                                  color: event.isCompleted
                                                      ? const Color(0xFF1FA87A)
                                                      : const Color(0xFF6B7385),
                                                  size: 26,
                                                ),
                                              ),
                                              const SizedBox(width: 10),
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Icon(
                                                          _categoryIcon(event.category),
                                                          size: 14,
                                                          color: color,
                                                        ),
                                                        const SizedBox(width: 6),
                                                        Expanded(
                                                          child: Text(
                                                            event.title,
                                                            maxLines: 1,
                                                            overflow: TextOverflow.ellipsis,
                                                            style: GoogleFonts.outfit(
                                                              fontSize: 15,
                                                              fontWeight: FontWeight.w700,
                                                              color: event.isCompleted
                                                                  ? const Color(0xFF7A8496)
                                                                  : Colors.white,
                                                              decoration: event.isCompleted
                                                                  ? TextDecoration.lineThrough
                                                                  : null,
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    if (event.description.isNotEmpty) ...[
                                                      const SizedBox(height: 3),
                                                      Text(
                                                        event.description,
                                                        maxLines: 1,
                                                        overflow: TextOverflow.ellipsis,
                                                        style: GoogleFonts.outfit(
                                                          fontSize: 12,
                                                          color: const Color(0xFF8B93A3),
                                                        ),
                                                      ),
                                                    ],
                                                    const SizedBox(height: 8),
                                                    Wrap(
                                                      spacing: 6,
                                                      runSpacing: 4,
                                                      children: [
                                                        _MetaChip(
                                                          icon: Icons.schedule_rounded,
                                                          label: event.isAllDay
                                                              ? 'All day'
                                                              : '${event.hour.toString().padLeft(2, '0')}:${event.minute.toString().padLeft(2, '0')}',
                                                        ),
                                                        if (rec.isNotEmpty)
                                                          _MetaChip(
                                                            icon: Icons.repeat_rounded,
                                                            label: rec,
                                                          ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              IconButton(
                                                tooltip: 'Delete',
                                                onPressed: () => _confirmDelete(event),
                                                icon: const Icon(
                                                  Icons.delete_outline_rounded,
                                                  size: 20,
                                                  color: Color(0xFF6B7385),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _Cat {
  final String id;
  final String label;
  final IconData icon;
  const _Cat(this.id, this.label, this.icon);
}

class _StatPill extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final bool selected;
  final VoidCallback? onTap;
  const _StatPill({
    required this.label,
    required this.value,
    required this.color,
    this.selected = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return AppPressable(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? color.withValues(alpha: 0.14) : const Color(0xFF171A21),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? color : const Color(0xFF2A2F3A),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: GoogleFonts.outfit(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: color,
                height: 1,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: GoogleFonts.outfit(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: selected ? Colors.white : const Color(0xFF8B93A3),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _MetaChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0xFF1E2330),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: const Color(0xFF8B93A3)),
          const SizedBox(width: 4),
          Text(
            label,
            style: GoogleFonts.outfit(
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              color: const Color(0xFFB8C0D0),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyEvents extends StatelessWidget {
  final bool hasAny;
  final VoidCallback onAdd;
  const _EmptyEvents({required this.hasAny, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFF171A21),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: const Color(0xFF2A2F3A)),
              ),
              child: Icon(
                hasAny ? Icons.search_off_rounded : Icons.event_note_rounded,
                size: 34,
                color: const Color(0xFF6B7385),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              hasAny ? 'No matching events' : 'No events yet',
              style: GoogleFonts.outfit(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 6),
            Text(
              hasAny
                  ? 'Try another search or category'
                  : 'Tap + to add your first reminder, meeting, or birthday',
              textAlign: TextAlign.center,
              style: GoogleFonts.outfit(fontSize: 13, color: Color(0xFF8B93A3)),
            ),
            if (!hasAny) ...[
              SizedBox(height: 18),
              FilledButton.icon(
                onPressed: onAdd,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.accent,
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.add_rounded),
                label: Text('Add event', style: GoogleFonts.outfit(fontWeight: FontWeight.w600)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
