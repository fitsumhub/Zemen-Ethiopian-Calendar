﻿import 'package:material_ui/material_ui.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../../core/calendar/ethiopian_calendar_engine.dart';
import '../../../../core/calendar/ethiopian_date.dart';
import '../../../../core/calendar/ethiopian_time_converter.dart';
import '../../../../core/localization/app_language.dart';
import '../../../../core/localization/locale_strings.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../data/models/event_entity.dart';

/// Easy add/edit event sheet — clear sections, dual dates, reminders.
class AddEditEventDialog extends StatefulWidget {
  final EthiopianDate initialDate;
  final EventEntity? eventToEdit;
  final AppLanguage currentLanguage;
  final VoidCallback onDismiss;
  final ValueChanged<EventEntity> onSave;

  const AddEditEventDialog({
    super.key,
    required this.initialDate,
    this.eventToEdit,
    this.currentLanguage = AppLanguage.amharic,
    required this.onDismiss,
    required this.onSave,
  });

  /// Preferred entry point — bottom sheet works on phone and desktop.
  static Future<void> open(
    BuildContext context, {
    required EthiopianDate initialDate,
    EventEntity? eventToEdit,
    AppLanguage currentLanguage = AppLanguage.amharic,
    required ValueChanged<EventEntity> onSave,
  }) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(ctx).bottom),
        child: AddEditEventDialog(
          initialDate: initialDate,
          eventToEdit: eventToEdit,
          currentLanguage: currentLanguage,
          onDismiss: () => Navigator.of(ctx).pop(),
          onSave: (event) {
            onSave(event);
            Navigator.of(ctx).pop();
          },
        ),
      ),
    );
  }

  @override
  State<AddEditEventDialog> createState() => _AddEditEventDialogState();
}

class _AddEditEventDialogState extends State<AddEditEventDialog> {
  late TextEditingController _titleController;
  late TextEditingController _descController;
  late String _category;
  late int _ethYear;
  late int _ethMonth;
  late int _ethDay;
  late bool _isAllDay;
  late int _hour;
  late int _minute;
  late String _recurrence;
  late int _reminderMinutes;
  late String _colorHex;

  final _categories = const [
    ('TASK', 'Task', Icons.check_circle_outline_rounded),
    ('MEETING', 'Meeting', Icons.groups_rounded),
    ('BIRTHDAY', 'Birthday', Icons.cake_rounded),
    ('EXAM', 'Exam', Icons.school_rounded),
    ('ANNIVERSARY', 'Anniversary', Icons.favorite_border_rounded),
    ('RELIGIOUS', 'Religious', Icons.temple_buddhist_rounded),
    ('CULTURAL', 'Cultural', Icons.public_rounded),
    ('OTHER', 'Other', Icons.more_horiz_rounded),
  ];

  final _reminders = const [
    (-1, 'No reminder'),
    (0, 'At time'),
    (5, '5 minutes before'),
    (15, '15 minutes before'),
    (30, '30 minutes before'),
    (60, '1 hour before'),
    (1440, '1 day before'),
  ];

  final _colors = const [
    '#F59E0B',
    '#10B981',
    '#3B82F6',
    '#8B5CF6',
    '#EF4444',
    '#EC4899',
    '#06B6D4',
  ];

  @override
  void initState() {
    super.initState();
    final edit = widget.eventToEdit;
    _titleController = TextEditingController(text: edit?.title ?? '');
    _descController = TextEditingController(text: edit?.description ?? '');
    _category = edit?.category ?? 'TASK';
    _ethYear = edit?.ethiopianYear ?? widget.initialDate.year;
    _ethMonth = edit?.ethiopianMonth ?? widget.initialDate.month;
    _ethDay = edit?.ethiopianDay ?? widget.initialDate.day;
    // New events/agenda items always start with a clock time (not all-day).
    if (edit != null) {
      _isAllDay = edit.isAllDay;
      _hour = edit.hour;
      _minute = edit.minute;
    } else {
      final now = TimeOfDay.now();
      _isAllDay = false;
      _hour = now.hour;
      _minute = (now.minute ~/ 5) * 5;
    }
    _recurrence = edit?.recurrence ?? 'NONE';
    _reminderMinutes = edit?.reminderMinutesBefore ?? 15;
    _colorHex = edit?.colorHex ?? '#F59E0B';
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  Color _parseHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 6 || hex.length == 7) buffer.write('ff');
    buffer.write(hex.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }

  InputDecoration _fieldDecoration(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      labelStyle: GoogleFonts.outfit(color: const Color(0xFF8B93A3), fontSize: 13),
      prefixIcon: icon == null ? null : Icon(icon, color: const Color(0xFF8B93A3), size: 20),
      filled: true,
      fillColor: const Color(0xFF12151C),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFF2A2F3A)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFF2A2F3A)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFFF6B6B)),
      ),
    );
  }

  void _save() {
    final title = _titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please enter a title', style: GoogleFonts.outfit()),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    _clampDayToMonth();
    final greg = EthiopianCalendarEngine.toGregorian(
      EthiopianDate(_ethYear, _ethMonth, _ethDay),
    );

    widget.onSave(
      EventEntity(
        id: widget.eventToEdit?.id ?? 0,
        title: title,
        description: _descController.text.trim(),
        category: _category,
        ethiopianYear: _ethYear,
        ethiopianMonth: _ethMonth,
        ethiopianDay: _ethDay,
        gregorianYear: greg.year,
        gregorianMonth: greg.month,
        gregorianDay: greg.day,
        hour: _isAllDay ? 8 : _hour,
        minute: _isAllDay ? 0 : _minute,
        isAllDay: _isAllDay,
        recurrence: _recurrence,
        reminderMinutesBefore: _reminderMinutes,
        colorHex: _colorHex,
        isCompleted: widget.eventToEdit?.isCompleted ?? false,
        createdAt: widget.eventToEdit?.createdAt ?? DateTime.now().millisecondsSinceEpoch,
      ),
    );
  }

  void _clampDayToMonth() {
    final maxDays = EthiopianDate.daysInMonthFor(_ethYear, _ethMonth);
    if (_ethDay > maxDays) _ethDay = maxDays;
  }

  void _setMonth(int month) {
    setState(() {
      _ethMonth = month;
      _clampDayToMonth();
    });
  }

  void _setYear(int year) {
    setState(() {
      _ethYear = year;
      _clampDayToMonth();
    });
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: _hour, minute: _minute),
      helpText: 'Select event time',
      builder: (context, child) {
        return Theme(
          data: ThemeData.dark(useMaterial3: true).copyWith(
            colorScheme: ColorScheme.dark(
              primary: AppColors.accent,
              secondary: AppColors.accentSoft,
              surface: Color(0xFF1A1D26),
              onSurface: Colors.white,
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
    if (picked == null || !mounted) return;
    setState(() {
      _hour = picked.hour;
      _minute = picked.minute;
      _isAllDay = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final maxDays = EthiopianDate.daysInMonthFor(_ethYear, _ethMonth);
    final safeDay = _ethDay.clamp(1, maxDays);
    if (safeDay != _ethDay) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        final latestMax = EthiopianDate.daysInMonthFor(_ethYear, _ethMonth);
        if (_ethDay > latestMax) {
          setState(() => _ethDay = latestMax);
        }
      });
    }

    final greg = EthiopianCalendarEngine.toGregorian(
      EthiopianDate(_ethYear, _ethMonth, safeDay),
    );
    final monthName = LocaleStrings.getMonthName(_ethMonth, widget.currentLanguage);
    final ethTime = EthiopianTimeConverter.gregorianToEthiopian(_hour, _minute);
    final isEdit = widget.eventToEdit != null;

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.sizeOf(context).height * 0.92,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF1A1D26),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 10),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFF3A4050),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 8, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    isEdit ? 'Edit event' : 'New event',
                    style: GoogleFonts.outfit(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: widget.onDismiss,
                  icon: const Icon(Icons.close_rounded, color: Color(0xFF8B93A3)),
                ),
              ],
            ),
          ),
          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _titleController,
                    style: GoogleFonts.outfit(color: Colors.white),
                    textInputAction: TextInputAction.next,
                    decoration: _fieldDecoration('Title *', icon: Icons.title_rounded),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _descController,
                    style: GoogleFonts.outfit(color: Colors.white),
                    maxLines: 2,
                    decoration: _fieldDecoration('Notes (optional)', icon: Icons.notes_rounded),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    'Category',
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF8B93A3),
                      letterSpacing: 0.4,
                    ),
                  ),
                  SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _categories.map((c) {
                      final selected = _category == c.$1;
                      return InkWell(
                        onTap: () => setState(() => _category = c.$1),
                        borderRadius: BorderRadius.circular(20),
                        child: AnimatedContainer(
                          duration: Duration(milliseconds: 140),
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: selected
                                ? AppColors.accent.withValues(alpha: 0.18)
                                : Color(0xFF12151C),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: selected ? AppColors.accent : Color(0xFF2A2F3A),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                c.$3,
                                size: 14,
                                color: selected ? const Color(0xFFFF8A80) : const Color(0xFF8B93A3),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                c.$2,
                                style: GoogleFonts.outfit(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: selected ? Colors.white : const Color(0xFF8B93A3),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    'Ethiopian date',
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF8B93A3),
                      letterSpacing: 0.4,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFF12151C),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFF2A2F3A)),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                '$monthName $_ethDay, $_ethYear E.C.',
                                style: GoogleFonts.outfit(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            Text(
                              '${greg.day}/${greg.month}/${greg.year} G.C.',
                              style: GoogleFonts.outfit(
                                fontSize: 12,
                                color: const Color(0xFFFF8A80),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: DropdownButtonFormField<int>(
                                key: ValueKey('em_$_ethMonth'),
                                initialValue: _ethMonth,
                                dropdownColor: const Color(0xFF1A1D26),
                                style: GoogleFonts.outfit(color: Colors.white, fontSize: 13),
                                decoration: _fieldDecoration('Month'),
                                items: List.generate(13, (i) => i + 1).map((m) {
                                  return DropdownMenuItem(
                                    value: m,
                                    child: Text(
                                      LocaleStrings.getMonthName(m, widget.currentLanguage),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  );
                                }).toList(),
                                onChanged: (val) => _setMonth(val ?? 1),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: DropdownButtonFormField<int>(
                                key: ValueKey('ed_${_ethYear}_${_ethMonth}_$maxDays'),
                                initialValue: safeDay,
                                dropdownColor: const Color(0xFF1A1D26),
                                style: GoogleFonts.outfit(color: Colors.white, fontSize: 13),
                                decoration: _fieldDecoration('Day'),
                                items: List.generate(maxDays, (i) => i + 1).map((d) {
                                  return DropdownMenuItem(value: d, child: Text('$d'));
                                }).toList(),
                                onChanged: (val) => setState(() => _ethDay = val ?? 1),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: DropdownButtonFormField<int>(
                                key: ValueKey('ey_$_ethYear'),
                                initialValue: _ethYear,
                                dropdownColor: const Color(0xFF1A1D26),
                                style: GoogleFonts.outfit(color: Colors.white, fontSize: 13),
                                decoration: _fieldDecoration('Year'),
                                items: List.generate(12, (i) => _ethYear - 5 + i).map((y) {
                                  return DropdownMenuItem(value: y, child: Text('$y'));
                                }).toList(),
                                onChanged: (val) => _setYear(val ?? 2017),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  // Time is primary for Events / Agenda — all-day is optional.
                  Text(
                    'ሰዓት · Time',
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.4,
                      color: const Color(0xFF8B93A3),
                    ),
                  ),
                  SizedBox(height: 8),
                  if (!_isAllDay)
                    InkWell(
                      onTap: _pickTime,
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 14,
                        ),
                        decoration: BoxDecoration(
                          color: Color(0xFF12151C),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppColors.accent.withValues(alpha: 0.55),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: AppColors.accent.withValues(alpha: 0.16),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                Icons.access_time_rounded,
                                color: AppColors.accent,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${_hour.toString().padLeft(2, '0')}:${_minute.toString().padLeft(2, '0')}',
                                    style: GoogleFonts.outfit(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  Text(
                                    '${ethTime.period.amharic} ${ethTime.hour}:${ethTime.minute.toString().padLeft(2, '0')} · Tap to change',
                                    style: GoogleFonts.outfit(
                                      fontSize: 12,
                                      color: const Color(0xFF8B93A3),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const Icon(
                              Icons.edit_rounded,
                              size: 18,
                              color: Color(0xFF8B93A3),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 14,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF12151C),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF2A2F3A)),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.wb_sunny_outlined,
                            color: Color(0xFF8B93A3),
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'ሙሉ ቀን · All day (no clock time)',
                            style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 10),
                  Material(
                    color: const Color(0xFF12151C),
                    borderRadius: BorderRadius.circular(12),
                    child: Ink(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF2A2F3A)),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        child: SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(
                            'ሙሉ ቀን · All day',
                            style: GoogleFonts.outfit(
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                          subtitle: Text(
                            _isAllDay
                                ? 'Turn off to set a specific time'
                                : 'Leave off to keep the event timed',
                            style: GoogleFonts.outfit(
                              fontSize: 12,
                              color: Color(0xFF8B93A3),
                            ),
                          ),
                          value: _isAllDay,
                          activeThumbColor: Colors.white,
                          activeTrackColor: AppColors.accent,
                          onChanged: (val) => setState(() => _isAllDay = val),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    key: ValueKey('rec_$_recurrence'),
                    initialValue: _recurrence,
                    dropdownColor: const Color(0xFF1A1D26),
                    style: GoogleFonts.outfit(color: Colors.white, fontSize: 14),
                    decoration: _fieldDecoration('Repeat', icon: Icons.repeat_rounded),
                    items: const [
                      DropdownMenuItem(value: 'NONE', child: Text('Does not repeat')),
                      DropdownMenuItem(value: 'DAILY', child: Text('Every day')),
                      DropdownMenuItem(value: 'WEEKLY', child: Text('Every week')),
                      DropdownMenuItem(value: 'MONTHLY_ETHIOPIAN', child: Text('Every Ethiopian month')),
                      DropdownMenuItem(value: 'MONTHLY_GREGORIAN', child: Text('Every Gregorian month')),
                      DropdownMenuItem(value: 'YEARLY_ETHIOPIAN', child: Text('Every Ethiopian year')),
                      DropdownMenuItem(value: 'YEARLY_GREGORIAN', child: Text('Every Gregorian year')),
                    ],
                    onChanged: (val) => setState(() => _recurrence = val ?? 'NONE'),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<int>(
                    key: ValueKey('rem_$_reminderMinutes'),
                    initialValue: _reminderMinutes,
                    dropdownColor: const Color(0xFF1A1D26),
                    style: GoogleFonts.outfit(color: Colors.white, fontSize: 14),
                    decoration: _fieldDecoration('Reminder', icon: Icons.notifications_none_rounded),
                    items: _reminders
                        .map((r) => DropdownMenuItem(value: r.$1, child: Text(r.$2)))
                        .toList(),
                    onChanged: (val) => setState(() => _reminderMinutes = val ?? 15),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Color',
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF8B93A3),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: _colors.map((c) {
                      final selected = _colorHex == c;
                      return Padding(
                        padding: const EdgeInsets.only(right: 10),
                        child: InkWell(
                          onTap: () => setState(() => _colorHex = c),
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              color: _parseHex(c),
                              shape: BoxShape.circle,
                              border: selected
                                  ? Border.all(color: Colors.white, width: 3)
                                  : null,
                              boxShadow: selected
                                  ? [
                                      BoxShadow(
                                        color: _parseHex(c).withValues(alpha: 0.45),
                                        blurRadius: 8,
                                      ),
                                    ]
                                  : null,
                            ),
                            child: selected
                                ? const Icon(Icons.check, size: 16, color: Colors.white)
                                : null,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: widget.onDismiss,
                          style: OutlinedButton.styleFrom(
                            foregroundColor: const Color(0xFFB8C0D0),
                            side: const BorderSide(color: Color(0xFF2A2F3A)),
                            padding: EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: Text('Cancel', style: GoogleFonts.outfit(fontWeight: FontWeight.w600)),
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        flex: 2,
                        child: FilledButton(
                          onPressed: _save,
                          style: FilledButton.styleFrom(
                            backgroundColor: AppColors.accent,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: Text(
                            isEdit ? 'Save changes' : 'Save event',
                            style: GoogleFonts.outfit(fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
