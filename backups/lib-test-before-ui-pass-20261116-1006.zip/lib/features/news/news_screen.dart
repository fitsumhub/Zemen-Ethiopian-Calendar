import 'package:material_ui/material_ui.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';

class NewsScreen extends StatelessWidget {
  const NewsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final news = [
      (
        'Ethiopian Premier League: Round 8 Marquee Clashes Scheduled',
        'Sports · Ethiopian Football',
        'Fasil Ketema takes on Ethiopia Nigd Bank while Kedus Giorgis faces Hadiya Hosaena in this weekend’s fixtures.',
        'Hidar 11, 2019',
        Icons.sports_soccer_rounded,
      ),
      (
        'Great Ethiopian Run Celebrates Record Participation in Addis Ababa',
        'Athletics · Culture',
        'Tens of thousands of participants take to the streets in the annual 10k international road race.',
        'Hidar 8, 2019',
        Icons.directions_run_rounded,
      ),
      (
        'Orthodox Tewahedo Church Observes Tsome Nebiyat (Fast of Prophets)',
        'Heritage · Faith',
        'The 43-day Nativity fasting period commences across dioceses in Ethiopia and the global diaspora.',
        'Hidar 15, 2019',
        Icons.church_rounded,
      ),
      (
        'National Green Legacy Initiative Expands Nursery Stations Nationwide',
        'Environment · Development',
        'Agricultural agencies prepare millions of drought-resistant seedlings for the upcoming planting cycle.',
        'Tikimt 28, 2019',
        Icons.eco_rounded,
      ),
    ];

    return ColoredBox(
      color: Colors.white,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        itemCount: news.length,
        separatorBuilder: (_, _) =>
            Divider(height: 20, color: Color(0xFFF0F0F2)),
        itemBuilder: (context, i) {
          final item = news[i];
          return InkWell(
            onTap: () {},
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: AppColors.accent.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(item.$5, color: AppColors.accent, size: 24),
                  ),
                  SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.$2,
                          style: GoogleFonts.outfit(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                            color: AppColors.accent,
                            letterSpacing: 0.3,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          item.$1,
                          style: GoogleFonts.outfit(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF1C1C1E),
                            height: 1.25,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item.$3,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.outfit(
                            fontSize: 12.5,
                            color: const Color(0xFF8E8E93),
                            height: 1.3,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          item.$4,
                          style: GoogleFonts.outfit(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: const Color(0xFFAEAEB2),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
