import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/ads/native_ad_widget.dart';
import '../../core/theme/app_colors.dart';
import 'football_data.dart';
import 'football_logo.dart';
import 'football_providers.dart';
import 'league_detail_screen.dart';
import 'match_detail_screen.dart';

/// Professional Football hub — leagues, live scores, fixtures.
class FootballScreen extends ConsumerStatefulWidget {
  const FootballScreen({super.key});

  @override
  ConsumerState<FootballScreen> createState() => _FootballScreenState();
}

class _FootballScreenState extends ConsumerState<FootballScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final activeFilter = ref.watch(footballFilterProvider);
    final searchQuery = ref.watch(footballSearchProvider);
    final allLeagues = ref.watch(footballCatalogProvider);
    final favorites = ref.watch(footballFavoritesProvider);

    return ColoredBox(
      color: AppColors.canvas,
      child: Column(
        children: [
          const _FootballHeroBar(),
          _FilterStrip(
            activeFilter: activeFilter,
            onSelect: (f) =>
                ref.read(footballFilterProvider.notifier).setFilter(f),
          ),
          Expanded(
            child: activeFilter == FootballFilter.leagues
                ? _LeagueListView(
                    leagues: allLeagues,
                    favorites: favorites,
                    searchQuery: searchQuery,
                    searchController: _searchController,
                    onSearchChanged: (q) =>
                        ref.read(footballSearchProvider.notifier).setQuery(q),
                    onToggleFav: (id) =>
                        ref.read(footballFavoritesProvider.notifier).toggle(id),
                  )
                : _MatchesListView(filter: activeFilter),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// HERO
// ---------------------------------------------------------------------------
class _FootballHeroBar extends ConsumerWidget {
  const _FootballHeroBar();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final refreshing = ref.watch(footballGlobalRefreshProvider);

    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(16, 10, 16, 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF0C1220),
            Color(0xFF151B28),
            Color(0xFF1A2333),
          ],
        ),
        border: Border(
          bottom: BorderSide(color: AppColors.surfaceBorder),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: const LinearGradient(
                colors: [Color(0xFF0D6B4C), Color(0xFF078930)],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF078930).withValues(alpha: 0.35),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Icon(Icons.sports_soccer_rounded,
                color: Colors.white, size: 22),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Football',
                  style: GoogleFonts.outfit(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                    height: 1.1,
                  ),
                ),
                Text(
                  refreshing
                      ? 'Refreshing live free APIs…'
                      : 'ESPN + TheSportsDB · multi-season',
                  style: GoogleFonts.outfit(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color: AppColors.accent.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppColors.accent.withValues(alpha: 0.45),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: AppColors.accent,
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 5),
                Text(
                  'LIVE',
                  style: GoogleFonts.outfit(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    color: AppColors.accent,
                    letterSpacing: 0.6,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(width: 8),
          Material(
            color: AppColors.surfaceElevated,
            borderRadius: BorderRadius.circular(12),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: refreshing
                  ? null
                  : () async {
                      final n = await ref
                          .read(footballGlobalRefreshProvider.notifier)
                          .refreshAll();
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          behavior: SnackBarBehavior.floating,
                          content: Text(
                            n > 0
                                ? 'Live football refreshed · $n leagues'
                                : 'Refresh in progress or failed — try again',
                            style: GoogleFonts.outfit(fontWeight: FontWeight.w600),
                          ),
                        ),
                      );
                    },
              child: SizedBox(
                width: 40,
                height: 40,
                child: Center(
                  child: refreshing
                      ? SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.2,
                            color: AppColors.accent,
                          ),
                        )
                      : Icon(
                          Icons.refresh_rounded,
                          color: AppColors.textPrimary,
                        ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// FILTER STRIP
// ---------------------------------------------------------------------------
class _FilterStrip extends StatelessWidget {
  final FootballFilter activeFilter;
  final ValueChanged<FootballFilter> onSelect;

  const _FilterStrip({
    required this.activeFilter,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final items = [
      (FootballFilter.leagues, 'Leagues', Icons.emoji_events_rounded),
      (FootballFilter.live, 'Live', Icons.fiber_manual_record_rounded),
      (FootballFilter.today, 'Today', Icons.today_rounded),
      (FootballFilter.upcoming, 'Upcoming', Icons.schedule_rounded),
      (FootballFilter.finished, 'Results', Icons.check_circle_outline_rounded),
    ];

    return Container(
      color: AppColors.surface,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: Row(
          children: items.map((item) {
            final isSelected = activeFilter == item.$1;
            final isLive = item.$1 == FootballFilter.live;

            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => onSelect(item.$1),
                  borderRadius: BorderRadius.circular(22),
                  child: AnimatedContainer(
                    duration: Duration(milliseconds: 180),
                    padding: EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      gradient: isSelected
                          ? LinearGradient(
                              colors: isLive
                                  ? [
                                      AppColors.accent,
                                      Color(0xFFB42318),
                                    ]
                                  : [
                                      AppColors.accent.withValues(alpha: 0.28),
                                      AppColors.accent.withValues(alpha: 0.12),
                                    ],
                            )
                          : null,
                      color: isSelected ? null : AppColors.surfaceElevated,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: isSelected
                            ? AppColors.accent
                            : AppColors.surfaceBorder,
                        width: isSelected ? 1.4 : 1,
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: AppColors.accent
                                    .withValues(alpha: 0.25),
                                blurRadius: 8,
                                offset: Offset(0, 2),
                              ),
                            ]
                          : null,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          item.$3,
                          size: isLive ? 11 : 14,
                          color: isSelected
                              ? (isLive ? Colors.white : AppColors.accent)
                              : (isLive
                                  ? AppColors.accent
                                  : AppColors.textSecondary),
                        ),
                        SizedBox(width: 6),
                        Text(
                          item.$2,
                          style: GoogleFonts.outfit(
                            fontSize: 12.5,
                            fontWeight: isSelected
                                ? FontWeight.w800
                                : FontWeight.w600,
                            color: isSelected
                                ? (isLive ? Colors.white : AppColors.textPrimary)
                                : AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// LEAGUE LIST
// ---------------------------------------------------------------------------
class _LeagueListView extends StatelessWidget {
  final List<FootballLeague> leagues;
  final Set<String> favorites;
  final String searchQuery;
  final TextEditingController searchController;
  final ValueChanged<String> onSearchChanged;
  final ValueChanged<String> onToggleFav;

  const _LeagueListView({
    required this.leagues,
    required this.favorites,
    required this.searchQuery,
    required this.searchController,
    required this.onSearchChanged,
    required this.onToggleFav,
  });

  @override
  Widget build(BuildContext context) {
    final q = searchQuery.trim().toLowerCase();
    final filtered = leagues.where((l) {
      if (q.isEmpty) return true;
      return l.name.toLowerCase().contains(q) ||
          l.shortName.toLowerCase().contains(q) ||
          (l.country?.toLowerCase().contains(q) ?? false);
    }).toList();

    final favLeagues =
        filtered.where((l) => favorites.contains(l.id)).toList();
    final otherLeagues =
        filtered.where((l) => !favorites.contains(l.id)).toList();

    return ListView(
      padding: EdgeInsets.fromLTRB(0, 0, 0, 28),
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: TextField(
            controller: searchController,
            onChanged: onSearchChanged,
            style: GoogleFonts.outfit(
              color: AppColors.textPrimary,
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              hintText: 'Search leagues & competitions…',
              hintStyle: GoogleFonts.outfit(
                color: AppColors.textTertiary,
                fontSize: 13.5,
              ),
              prefixIcon: Icon(Icons.search_rounded,
                  color: AppColors.textSecondary),
              suffixIcon: searchQuery.isNotEmpty
                  ? IconButton(
                      icon: Icon(Icons.clear_rounded,
                          color: AppColors.textSecondary),
                      onPressed: () {
                        searchController.clear();
                        onSearchChanged('');
                      },
                    )
                  : null,
              filled: true,
              fillColor: AppColors.surfaceElevated,
              contentPadding: EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 12,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: AppColors.surfaceBorder),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(color: AppColors.surfaceBorder),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(
                  color: AppColors.accent,
                  width: 1.4,
                ),
              ),
            ),
          ),
        ),
        if (favLeagues.isNotEmpty) ...[
          _SectionLabel(
            title: 'Favorites',
            subtitle: '${favLeagues.length}',
            icon: Icons.star_rounded,
            iconColor: AppColors.govHolidayGlow,
          ),
          ...favLeagues.map(
            (l) => _LeagueTile(
              league: l,
              isFavorite: true,
              onToggleFav: () => onToggleFav(l.id),
            ),
          ),
          const SizedBox(height: 6),
        ],
        _SectionLabel(
          title: favLeagues.isEmpty ? 'All competitions' : 'All leagues',
          subtitle: '${otherLeagues.length}',
          icon: Icons.public_rounded,
        ),
        if (filtered.isEmpty)
          _EmptyPane(
            icon: Icons.search_off_rounded,
            title: 'No leagues found',
            subtitle: 'Try another search term',
          )
        else
          ...otherLeagues.map(
            (l) => _LeagueTile(
              league: l,
              isFavorite: favorites.contains(l.id),
              onToggleFav: () => onToggleFav(l.id),
            ),
          ),
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color? iconColor;

  const _SectionLabel({
    required this.title,
    required this.subtitle,
    required this.icon,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Row(
        children: [
          Icon(icon, size: 16, color: iconColor ?? AppColors.textSecondary),
          SizedBox(width: 6),
          Text(
            title,
            style: GoogleFonts.outfit(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          SizedBox(width: 8),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(
              color: AppColors.surfaceElevated,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.surfaceBorder),
            ),
            child: Text(
              subtitle,
              style: GoogleFonts.outfit(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LeagueTile extends StatelessWidget {
  final FootballLeague league;
  final bool isFavorite;
  final VoidCallback onToggleFav;

  const _LeagueTile({
    required this.league,
    required this.isFavorite,
    required this.onToggleFav,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => LeagueDetailScreen(leagueId: league.id),
            ),
          );
        },
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: AppColors.surfaceBorder),
            ),
          ),
          child: Row(
            children: [
              FootballLogo.league(league, size: 46, elevated: true),
              SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      league.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.outfit(
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      [
                        if (league.country != null && league.country!.isNotEmpty)
                          league.country!,
                        if (league.season.isNotEmpty) league.season,
                        if (league.shortName.isNotEmpty) league.shortName,
                      ].join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: isFavorite ? 'Remove favorite' : 'Add favorite',
                onPressed: onToggleFav,
                icon: Icon(
                  isFavorite ? Icons.star_rounded : Icons.star_outline_rounded,
                  color: isFavorite
                      ? AppColors.govHolidayGlow
                      : AppColors.textTertiary,
                ),
              ),
              Icon(
                Icons.chevron_right_rounded,
                color: AppColors.textTertiary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// MATCHES LIST
// ---------------------------------------------------------------------------
class _MatchesListView extends ConsumerWidget {
  final FootballFilter filter;
  const _MatchesListView({required this.filter});

  bool _isToday(FootballMatch m) {
    if (m.kickoff != null) {
      final n = DateTime.now();
      final k = m.kickoff!;
      return k.year == n.year && k.month == n.month && k.day == n.day;
    }
    // Without kickoff, only treat live matches as "today".
    return m.isLive;
  }

  List<FootballMatch> _filterMatches(List<FootballMatch> matches) {
    switch (filter) {
      case FootballFilter.live:
        return matches.where((m) => m.isLive).toList();
      case FootballFilter.today:
        return matches.where(_isToday).toList();
      case FootballFilter.upcoming:
        return matches.where((m) => m.isScheduled).toList();
      case FootballFilter.finished:
        return matches.where((m) => m.isFinished).toList();
      case FootballFilter.leagues:
        return matches;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Live / Today use dedicated lightweight ESPN endpoints to avoid
    // warming every competition provider on the home strip.
    if (filter == FootballFilter.live) {
      final async = ref.watch(footballLiveMatchesProvider);
      return async.when(
        loading: () => Center(
          child: CircularProgressIndicator(color: AppColors.accent),
        ),
        error: (err, _) => Center(
          child: Text(
            'Could not load live scores',
            style: GoogleFonts.outfit(color: AppColors.textSecondary),
          ),
        ),
        data: (matches) {
          if (matches.isEmpty) {
            return Center(
              child: Text(
                'No live matches right now',
                style: GoogleFonts.outfit(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            );
          }
          return _CrossLeagueMatchList(matches: matches);
        },
      );
    }

    if (filter == FootballFilter.today) {
      final async = ref.watch(footballTodayMatchesProvider);
      return async.when(
        loading: () => Center(
          child: CircularProgressIndicator(color: AppColors.accent),
        ),
        error: (err, _) => Center(
          child: Text(
            'Could not load today\'s fixtures',
            style: GoogleFonts.outfit(color: AppColors.textSecondary),
          ),
        ),
        data: (matches) {
          if (matches.isEmpty) {
            return Center(
              child: Text(
                'No matches scheduled for today',
                style: GoogleFonts.outfit(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            );
          }
          return _CrossLeagueMatchList(matches: matches);
        },
      );
    }

    final catalog = ref.watch(footballCatalogProvider);
    var loadingCount = 0;
    var hasAny = false;

    final children = <Widget>[];

    for (var i = 0; i < catalog.length; i++) {
      final meta = catalog[i];
      final async = ref.watch(footballLeagueProvider(meta.id));

      async.when(
        loading: () {
          loadingCount++;
        },
        error: (_, _) {},
        data: (league) {
          final matches = _filterMatches(league.matches);
          if (matches.isEmpty) return;
          hasAny = true;
          children.add(
            _LeagueMatchGroup(
              league: league,
              matches: matches,
              showAd: i == 1,
            ),
          );
        },
      );
    }

    if (!hasAny && loadingCount > 0) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: AppColors.accent),
            SizedBox(height: 12),
            Text(
              'Loading fixtures…',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      );
    }

    if (!hasAny) {
      final label = switch (filter) {
        FootballFilter.live => 'No live matches right now',
        FootballFilter.today => 'No matches scheduled for today',
        FootballFilter.upcoming => 'No upcoming fixtures',
        FootballFilter.finished => 'No recent results',
        FootballFilter.leagues => 'No matches',
      };
      return _EmptyPane(
        icon: Icons.sports_soccer_outlined,
        title: label,
        subtitle: 'Pull to refresh or check another tab',
      );
    }

    return RefreshIndicator(
      color: AppColors.accent,
      backgroundColor: AppColors.surface,
      onRefresh: () async {
        await ref.read(footballGlobalRefreshProvider.notifier).refreshAll();
      },
      child: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 28),
        children: children,
      ),
    );
  }
}

class _CrossLeagueMatchList extends ConsumerWidget {
  final List<FootballMatch> matches;
  const _CrossLeagueMatchList({required this.matches});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final byComp = <String, List<FootballMatch>>{};
    for (final m in matches) {
      final key = m.competitionId.isNotEmpty
          ? m.competitionId
          : m.competitionName;
      byComp.putIfAbsent(key, () => []).add(m);
    }

    final children = <Widget>[];
    var i = 0;
    for (final entry in byComp.entries) {
      final meta = FootballData.catalogById(entry.key);
      final league = meta ??
          FootballLeague(
            id: entry.key,
            name: entry.value.first.competitionName.isNotEmpty
                ? entry.value.first.competitionName
                : entry.key,
            shortName: entry.key,
            mark: const ColorMark('FC', 0xFF37474F),
            matches: entry.value,
            standings: [],
          );
      children.add(
        _LeagueMatchGroup(
          league: league.copyWith(matches: entry.value),
          matches: entry.value,
          showAd: i == 1,
        ),
      );
      i++;
    }

    return RefreshIndicator(
      color: AppColors.accent,
      backgroundColor: AppColors.surface,
      onRefresh: () async {
        ref.invalidate(footballLiveMatchesProvider);
        ref.invalidate(footballTodayMatchesProvider);
        await ref.read(footballGlobalRefreshProvider.notifier).refreshAll();
      },
      child: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 28),
        children: children,
      ),
    );
  }
}

class _LeagueMatchGroup extends StatelessWidget {
  final FootballLeague league;
  final List<FootballMatch> matches;
  final bool showAd;

  const _LeagueMatchGroup({
    required this.league,
    required this.matches,
    this.showAd = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Material(
          color: AppColors.surfaceElevated,
          child: InkWell(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => LeagueDetailScreen(leagueId: league.id),
                ),
              );
            },
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  FootballLogo.league(league, size: 24, elevated: false),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      league.name,
                      style: GoogleFonts.outfit(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                  Text(
                    '${matches.length}',
                    style: GoogleFonts.outfit(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  SizedBox(width: 4),
                  Icon(Icons.chevron_right_rounded,
                      size: 18, color: AppColors.textTertiary),
                ],
              ),
            ),
          ),
        ),
        ...matches.map((m) => _HomeMatchRow(match: m)),
        if (showAd)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: NativeAdWidget(),
          ),
        const SizedBox(height: 6),
      ],
    );
  }
}

class _HomeMatchRow extends StatelessWidget {
  final FootballMatch match;
  const _HomeMatchRow({required this.match});

  @override
  Widget build(BuildContext context) {
    final status = match.isLive
        ? (match.statusLabel ?? 'LIVE')
        : match.isFinished
            ? (match.statusLabel ?? 'FT')
            : (match.statusLabel ??
                [
                  if (match.time != null) match.time!,
                  if (match.period != null) match.period!,
                ].join(' '));

    return Material(
      color: AppColors.surface,
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => MatchDetailScreen(match: match),
            ),
          );
        },
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: AppColors.surfaceBorder),
            ),
            color: match.isLive
                ? AppColors.accent.withValues(alpha: 0.05)
                : null,
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Flexible(
                          child: Text(
                            match.home.shortName.isNotEmpty
                                ? match.home.shortName
                                : match.home.name,
                            textAlign: TextAlign.right,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.outfit(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        FootballLogo.team(match.home, size: 28),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 86,
                    child: Column(
                      children: [
                        Text(
                          match.hasScore
                              ? '${match.homeScore}  –  ${match.awayScore}'
                              : 'vs',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.outfit(
                            fontSize: match.hasScore ? 16 : 13,
                            fontWeight: FontWeight.w900,
                            color: match.isLive
                                ? AppColors.accent
                                : AppColors.textPrimary,
                            letterSpacing: match.hasScore ? 0.5 : 0,
                          ),
                        ),
                        SizedBox(height: 3),
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: match.isLive
                                ? AppColors.accent
                                : match.isFinished
                                    ? AppColors.surfaceElevated
                                    : Color(0xFF1E3A5F),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            status,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.outfit(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              color: match.isLive
                                  ? Colors.white
                                  : match.isFinished
                                      ? AppColors.textSecondary
                                      : const Color(0xFF93C5FD),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Row(
                      children: [
                        FootballLogo.team(match.away, size: 28),
                        SizedBox(width: 8),
                        Flexible(
                          child: Text(
                            match.away.shortName.isNotEmpty
                                ? match.away.shortName
                                : match.away.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.outfit(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: AppColors.textPrimary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              if (match.dateHeader.isNotEmpty ||
                  (match.venue != null && match.venue!.isNotEmpty)) ...[
                SizedBox(height: 8),
                Row(
                  children: [
                    if (match.dateHeader.isNotEmpty)
                      Expanded(
                        child: Text(
                          match.dateHeader,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.outfit(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textTertiary,
                          ),
                        ),
                      ),
                    if (match.venue != null && match.venue!.isNotEmpty)
                      Flexible(
                        child: Text(
                          match.venue!,
                          textAlign: TextAlign.right,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.outfit(
                            fontSize: 10.5,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textTertiary,
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyPane extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EmptyPane({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 48, horizontal: 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 42, color: AppColors.textTertiary),
          SizedBox(height: 12),
          Text(
            title,
            textAlign: TextAlign.center,
            style: GoogleFonts.outfit(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: GoogleFonts.outfit(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}
