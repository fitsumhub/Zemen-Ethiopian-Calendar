import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/theme/app_colors.dart';
import 'football_api_service.dart';
import 'football_data.dart';
import 'football_logo.dart';
import 'football_providers.dart';
import 'match_detail_screen.dart';

/// League Detail — Schedule, Standings, Teams, Stats on dark canvas.
/// - Primary tabs: Schedule & Standings (plus Teams, Stats)
/// - Schedule tab: Date groups ("Friday, Tikimt 27", "Friday, Hidar 11")
///   Match rows: [Home Team] [Home Logo] [Score/Time] [Away Logo] [Away Team]
/// - Full yearly live schedule round selector: [All Season | R1 | R2 ... R34/38]
/// - Standings tab: [#] [Crest] [Team Name] [P] [GD] [PTS]
/// - Tap any fixture to open deep MatchDetailScreen
class LeagueDetailScreen extends ConsumerStatefulWidget {
  final String leagueId;

  const LeagueDetailScreen({super.key, required this.leagueId});

  @override
  ConsumerState<LeagueDetailScreen> createState() => _LeagueDetailScreenState();
}

class _LeagueDetailScreenState extends ConsumerState<LeagueDetailScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final meta = FootballData.catalogById(widget.leagueId);
    final async = ref.watch(footballLeagueProvider(widget.leagueId));
    final isFav =
        ref.watch(footballFavoritesProvider).contains(widget.leagueId);
    final isRefreshing =
        ref.watch(footballLeagueRefreshingProvider(widget.leagueId));
    final leagueData = async.asData?.value;
    final fetchedAt = leagueData?.fetchedAt;
    final sourceLabel = leagueData?.sourceLabel;

    return Scaffold(
      backgroundColor: AppColors.canvas,
      appBar: AppBar(
        backgroundColor: AppColors.canvas,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColors.textPrimary),
          onPressed: () => Navigator.of(context).pop(),
        ),
        titleSpacing: 8,
        title: Row(
          children: [
            if (meta != null) ...[
              FootballLogo.league(meta, size: 30, elevated: false),
              SizedBox(width: 10),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    meta?.name ?? 'League',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.outfit(
                      color: AppColors.textPrimary,
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                    ),
                  ),
                  if (meta != null)
                    Text(
                      [
                        ?meta.country,
                        meta.season,
                        ?sourceLabel,
                      ].join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.outfit(
                        color: AppColors.textSecondary,
                        fontWeight: FontWeight.w600,
                        fontSize: 11,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: isFav ? 'Remove favorite' : 'Add favorite',
            icon: Icon(
              isFav ? Icons.star_rounded : Icons.star_outline_rounded,
              color: isFav ? AppColors.govHolidayGlow : AppColors.textSecondary,
            ),
            onPressed: () {
              ref
                  .read(footballFavoritesProvider.notifier)
                  .toggle(widget.leagueId);
            },
          ),
          _ActiveRefreshButton(
            refreshing: isRefreshing,
            lastUpdated: fetchedAt,
            onRefresh: () async {
              final ok = await ref
                  .read(footballLeagueProvider(widget.leagueId).notifier)
                  .refresh();
              if (!context.mounted) return;
              final league = ref
                  .read(footballLeagueProvider(widget.leagueId))
                  .asData
                  ?.value;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  behavior: SnackBarBehavior.floating,
                  content: Text(
                    ok
                        ? 'Live data refreshed · ${league?.matches.length ?? 0} fixtures'
                            '${league?.sourceLabel != null ? ' · ${league!.sourceLabel}' : ''}'
                        : 'Refresh failed — showing last good data',
                    style: GoogleFonts.outfit(fontWeight: FontWeight.w600),
                  ),
                  duration: Duration(seconds: 2),
                ),
              );
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(44),
          child: Column(
            children: [
              TabBar(
                controller: _tabs,
                labelColor: AppColors.accent,
                unselectedLabelColor: AppColors.textSecondary,
                indicatorColor: AppColors.accent,
                indicatorWeight: 3,
                indicatorSize: TabBarIndicatorSize.tab,
                labelStyle: GoogleFonts.outfit(
                    fontWeight: FontWeight.w700, fontSize: 14),
                unselectedLabelStyle: GoogleFonts.outfit(
                    fontWeight: FontWeight.w500, fontSize: 14),
                tabs: [
                  Tab(text: 'Schedule'),
                  Tab(text: 'Standings'),
                  Tab(text: 'Teams'),
                  Tab(text: 'Stats'),
                ],
              ),
              Divider(
                  height: 1, thickness: 1, color: AppColors.surfaceBorder),
            ],
          ),
        ),
      ),
      body: Column(
        children: [
          _SeasonSelector(leagueId: widget.leagueId),
          Expanded(
            child: async.when(
              loading: () => Center(
                child: CircularProgressIndicator(color: AppColors.accent),
              ),
              error: (err, _) => _ErrorPane(
                message: '$err',
                onRetry: () => ref
                    .read(footballLeagueProvider(widget.leagueId).notifier)
                    .refresh(),
              ),
              data: (league) => TabBarView(
                controller: _tabs,
                children: [
                  RefreshIndicator(
                    color: AppColors.accent,
                    backgroundColor: AppColors.surface,
                    onRefresh: () => ref
                        .read(footballLeagueProvider(widget.leagueId).notifier)
                        .refresh(),
                    child: _ScheduleTab(league: league),
                  ),
                  RefreshIndicator(
                    color: AppColors.accent,
                    backgroundColor: AppColors.surface,
                    onRefresh: () => ref
                        .read(footballLeagueProvider(widget.leagueId).notifier)
                        .refresh(),
                    child: _StandingsTab(league: league),
                  ),
                  RefreshIndicator(
                    color: AppColors.accent,
                    backgroundColor: AppColors.surface,
                    onRefresh: () => ref
                        .read(footballLeagueProvider(widget.leagueId).notifier)
                        .refresh(),
                    child: _TeamsTab(league: league),
                  ),
                  RefreshIndicator(
                    color: AppColors.accent,
                    backgroundColor: AppColors.surface,
                    onRefresh: () => ref
                        .read(footballLeagueProvider(widget.leagueId).notifier)
                        .refresh(),
                    child: _StatsTab(league: league),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Compact season chips — uses TheSportsDB season keys when available.
class _SeasonSelector extends ConsumerWidget {
  final String leagueId;
  const _SeasonSelector({required this.leagueId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final source = FootballData.sourceFor(leagueId);
    final seasons = source.sportsDbSeasons;
    if (seasons.isEmpty) return const SizedBox.shrink();

    final selected = ref.watch(footballSeasonProvider(leagueId));
    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.fromLTRB(12, 6, 12, 6),
        itemCount: seasons.length + 1,
        separatorBuilder: (_, _) => SizedBox(width: 8),
        itemBuilder: (context, i) {
          final value = i == 0 ? null : seasons[i - 1];
          final label = i == 0 ? 'All seasons' : seasons[i - 1];
          final isSel = selected == value;
          return ChoiceChip(
            label: Text(
              label,
              style: GoogleFonts.outfit(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: isSel ? Colors.white : AppColors.textSecondary,
              ),
            ),
            selected: isSel,
            onSelected: (_) {
              ref.read(footballSeasonProvider(leagueId).notifier).setSeason(value);
            },
            selectedColor: AppColors.accent,
            backgroundColor: AppColors.surfaceElevated,
            side: BorderSide(
              color: isSel ? AppColors.accent : AppColors.surfaceBorder,
            ),
            visualDensity: VisualDensity.compact,
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// ERROR PANE
// ---------------------------------------------------------------------------
class _ErrorPane extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorPane({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.wifi_off_rounded,
                size: 40, color: AppColors.textSecondary),
            SizedBox(height: 12),
            Text(
              'Could not load live football data',
              style: GoogleFonts.outfit(
                fontWeight: FontWeight.w700,
                fontSize: 16,
                color: AppColors.textPrimary,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 6),
            Text(
              message,
              style: GoogleFonts.outfit(
                  fontSize: 12, color: AppColors.textSecondary),
              textAlign: TextAlign.center,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 16),
            FilledButton(
              onPressed: onRetry,
              style: FilledButton.styleFrom(
                  backgroundColor: AppColors.accent,
                  foregroundColor: Colors.white),
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// TAB 1: SCHEDULE (FULL YEARLY LIVE SCHEDULE & ROUND BROWSER)
// ---------------------------------------------------------------------------
class _ScheduleTab extends StatefulWidget {
  final FootballLeague league;
  const _ScheduleTab({required this.league});

  @override
  State<_ScheduleTab> createState() => _ScheduleTabState();
}

class _ScheduleTabState extends State<_ScheduleTab> {
  int? _selectedRound;
  final ScrollController _roundScrollController = ScrollController();

  @override
  void dispose() {
    _roundScrollController.dispose();
    super.dispose();
  }

  int _findCurrentRound() {
    final live = widget.league.matches.where((m) => m.isLive && m.round != null);
    if (live.isNotEmpty) return live.first.round!;

    final sched =
        widget.league.matches.where((m) => m.isScheduled && m.round != null);
    if (sched.isNotEmpty) return sched.first.round!;

    final fin =
        widget.league.matches.where((m) => m.isFinished && m.round != null);
    if (fin.isNotEmpty) return fin.last.round!;

    return 1;
  }

  @override
  Widget build(BuildContext context) {
    if (widget.league.matches.isEmpty) {
      return ListView(
        physics: AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: 120),
          Center(
            child: Text(
              'No fixtures scheduled',
              style: GoogleFonts.outfit(color: AppColors.textSecondary),
            ),
          ),
        ],
      );
    }

    final roundsSet = <int>{};
    for (final m in widget.league.matches) {
      if (m.round != null) roundsSet.add(m.round!);
    }
    final sortedRounds = roundsSet.toList()..sort();
    final currentRound = _findCurrentRound();

    var matches = widget.league.matches;
    if (_selectedRound != null) {
      matches = matches.where((m) => m.round == _selectedRound).toList();
    }

    final grouped = <String, List<FootballMatch>>{};
    for (final m in matches) {
      final header = m.dateHeader;
      grouped.putIfAbsent(header, () => []).add(m);
    }
    final headers = grouped.keys.toList();

    return Column(
      children: [
        // Yearly Schedule Header & Round Selector
        if (sortedRounds.length > 1) ...[
          Container(
            color: AppColors.surfaceElevated,
            padding: EdgeInsets.fromLTRB(14, 8, 14, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      '${widget.league.matches.length} Matches · Full Season',
                      style: GoogleFonts.outfit(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    Spacer(),
                    InkWell(
                      onTap: () {
                        setState(() => _selectedRound = currentRound);
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppColors.accent.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppColors.accent.withValues(alpha: 0.3),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 5,
                              height: 5,
                              margin: EdgeInsets.only(right: 5),
                              decoration: BoxDecoration(
                                color: AppColors.accent,
                                shape: BoxShape.circle,
                              ),
                            ),
                            Text(
                              'Active: Round $currentRound',
                              style: GoogleFonts.outfit(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w700,
                                color: AppColors.accent,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),

                // Horizontal Round Chips
                SizedBox(
                  height: 32,
                  child: ListView.builder(
                    controller: _roundScrollController,
                    scrollDirection: Axis.horizontal,
                    itemCount: sortedRounds.length + 1,
                    itemBuilder: (context, i) {
                      if (i == 0) {
                        final isSel = _selectedRound == null;
                        return Padding(
                          padding: EdgeInsets.only(right: 6),
                          child: ChoiceChip(
                            label: Text(
                              'All Season',
                              style: GoogleFonts.outfit(
                                fontSize: 11.5,
                                fontWeight:
                                    isSel ? FontWeight.w700 : FontWeight.w500,
                                color: isSel
                                    ? Colors.white
                                    : AppColors.textPrimary,
                              ),
                            ),
                            selected: isSel,
                            selectedColor: AppColors.accent,
                            backgroundColor: AppColors.surfaceElevated,
                            side: BorderSide(
                              color: isSel
                                  ? AppColors.accent
                                  : AppColors.surfaceBorder,
                            ),
                            onSelected: (_) =>
                                setState(() => _selectedRound = null),
                          ),
                        );
                      }

                      final r = sortedRounds[i - 1];
                      final isSel = _selectedRound == r;
                      final isCurrent = r == currentRound;

                      return Padding(
                        padding: EdgeInsets.only(right: 6),
                        child: ChoiceChip(
                          label: Text(
                            isCurrent ? 'R$r (Live)' : 'R$r',
                            style: GoogleFonts.outfit(
                              fontSize: 11.5,
                              fontWeight:
                                  isSel ? FontWeight.w700 : FontWeight.w500,
                              color: isSel
                                  ? Colors.white
                                  : (isCurrent
                                      ? AppColors.accent
                                      : AppColors.textPrimary),
                            ),
                          ),
                          selected: isSel,
                          selectedColor: AppColors.accent,
                          backgroundColor: AppColors.surfaceElevated,
                          side: BorderSide(
                            color: isSel
                                ? AppColors.accent
                                : (isCurrent
                                    ? AppColors.accent
                                    : AppColors.surfaceBorder),
                          ),
                          onSelected: (_) => setState(() => _selectedRound = r),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: AppColors.surfaceBorder),
        ],

        // Matches list
        Expanded(
          child: matches.isEmpty
              ? Center(
                  child: Text(
                    'No fixtures found for this round',
                    style: GoogleFonts.outfit(color: AppColors.textSecondary),
                  ),
                )
              : ListView.builder(
                  physics: AlwaysScrollableScrollPhysics(),
                  itemCount: headers.length,
                  itemBuilder: (context, i) {
                    final header = headers[i];
                    final rMatches = grouped[header]!;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Date section header bar (Screenshots 2 & 4)
                        Container(
                          width: double.infinity,
                          color: AppColors.surfaceElevated,
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          child: Text(
                            header,
                            style: GoogleFonts.outfit(
                              color: AppColors.textPrimary,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        ...rMatches.map((m) => _MatchRow(match: m)),
                      ],
                    );
                  },
                ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// MATCH ROW (Screenshots 2 & 4)
// ---------------------------------------------------------------------------
class _MatchRow extends StatelessWidget {
  final FootballMatch match;
  const _MatchRow({required this.match});

  @override
  Widget build(BuildContext context) {
    final live = match.isLive;

    return InkWell(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => MatchDetailScreen(match: match),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: live
              ? AppColors.accent.withValues(alpha: 0.05)
              : AppColors.surface,
          border: Border(
            bottom: BorderSide(color: AppColors.surfaceBorder),
          ),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            // Home Team Name & Logo
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Flexible(
                    child: Text(
                      match.home.name,
                      textAlign: TextAlign.right,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.outfit(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FootballLogo.team(match.home, size: 28),
                ],
              ),
            ),

            // Middle: Score or Kickoff Time (Screenshots 2 & 4)
            SizedBox(
              width: 82,
              child: match.hasScore
                  ? Column(
                      children: [
                        Text(
                          '${match.homeScore} - ${match.awayScore}',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.outfit(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                            color: live
                                ? AppColors.accent
                                : AppColors.textPrimary,
                          ),
                        ),
                        if (live)
                          Text(
                            'LIVE',
                            style: GoogleFonts.outfit(
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                              color: AppColors.accent,
                            ),
                          ),
                      ],
                    )
                  : Column(
                      children: [
                        Text(
                          match.time ?? match.statusLabel ?? '',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.outfit(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        if (match.statusLabel != null &&
                            match.time != null &&
                            match.time!.contains('PM'))
                          Text(
                            'PM',
                            style: GoogleFonts.outfit(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textSecondary,
                            ),
                          ),
                      ],
                    ),
            ),

            // Away Team Logo & Name
            Expanded(
              child: Row(
                children: [
                  FootballLogo.team(match.away, size: 28),
                  SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      match.away.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: GoogleFonts.outfit(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// TAB 2: STANDINGS (Screenshots 3 & 5)
// ---------------------------------------------------------------------------
class _StandingsTab extends StatelessWidget {
  final FootballLeague league;
  const _StandingsTab({required this.league});

  @override
  Widget build(BuildContext context) {
    if (league.standings.isEmpty) {
      return ListView(
        physics: AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: 120),
          Center(
            child: Text(
              'Standings unavailable',
              style: GoogleFonts.outfit(color: AppColors.textSecondary),
            ),
          ),
        ],
      );
    }

    return Column(
      children: [
        // Column Header: Rank, Crest, Team, P, GD, PTS (Screenshots 3 & 5)
        Container(
          color: AppColors.surfaceElevated,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              const SizedBox(width: 24),
              const SizedBox(width: 24),
              const SizedBox(width: 8),
              const Spacer(),
              _colHead('P', 38),
              _colHead('GD', 46),
              _colHead('PTS', 44),
            ],
          ),
        ),

        // Standings Rows
        Expanded(
          child: ListView.separated(
            physics: AlwaysScrollableScrollPhysics(),
            itemCount: league.standings.length,
            separatorBuilder: (_, _) => Divider(
              height: 1,
              color: AppColors.surfaceBorder,
            ),
            itemBuilder: (context, i) {
              final row = league.standings[i];
              final gdText = row.gd > 0 ? '+${row.gd}' : '${row.gd}';

              return Padding(
                padding:
                    EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                child: Row(
                  children: [
                    // Rank
                    SizedBox(
                      width: 24,
                      child: Text(
                        '${row.rank}',
                        style: GoogleFonts.outfit(
                          color: AppColors.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),

                    // Team Crest
                    FootballLogo.team(row.team, size: 24),
                    SizedBox(width: 10),

                    // Team Name
                    Expanded(
                      child: Text(
                        row.team.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.outfit(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),

                    // Played
                    SizedBox(
                      width: 38,
                      child: Text(
                        '${row.played}',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.outfit(
                          fontSize: 13.5,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),

                    // Goal Difference
                    SizedBox(
                      width: 46,
                      child: Text(
                        gdText,
                        textAlign: TextAlign.center,
                        style: GoogleFonts.outfit(
                          fontSize: 13.5,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),

                    // Points (Bold Black, Screenshots 3 & 5)
                    SizedBox(
                      width: 44,
                      child: Text(
                        '${row.pts}',
                        textAlign: TextAlign.center,
                        style: GoogleFonts.outfit(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _colHead(String text, double width) {
    return SizedBox(
      width: width,
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: GoogleFonts.outfit(
          fontSize: 12,
          color: AppColors.textSecondary,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// TAB 3: TEAMS
// ---------------------------------------------------------------------------
class _TeamsTab extends StatelessWidget {
  final FootballLeague league;
  const _TeamsTab({required this.league});

  @override
  Widget build(BuildContext context) {
    final teams = league.teams;
    return ListView.separated(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      itemCount: teams.length,
      separatorBuilder: (_, _) =>
          Divider(height: 1, color: AppColors.surfaceBorder),
      itemBuilder: (context, i) {
        final team = teams[i];
        return Padding(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Row(
            children: [
              FootballLogo.team(team, size: 36),
              SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      team.name,
                      style: GoogleFonts.outfit(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    if (team.stadium != null)
                      Text(
                        '${team.stadium} · ${team.city ?? ''}',
                        style: GoogleFonts.outfit(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// TAB 4: STATS
// ---------------------------------------------------------------------------
class _StatsTab extends StatelessWidget {
  final FootballLeague league;
  const _StatsTab({required this.league});

  @override
  Widget build(BuildContext context) {
    final scorers = league.topScorers;
    final attack = FootballApiService.attackLeaders(league.standings);
    final defence = FootballApiService.defenceLeaders(league.standings);
    final seasonLabel = league.id == 'epl_eth'
        ? 'CBE Ethiopian Premier League · 2025/26'
        : '${league.season} · Top scorers';

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      children: [
        _StatsSectionHeader(
          title: 'Top Scorers',
          subtitle: seasonLabel,
          icon: Icons.sports_soccer_rounded,
        ),
        const SizedBox(height: 8),
        if (scorers.isEmpty)
          _StatsEmptyCard(
            message: 'Player scorers unavailable from free APIs for this league.',
            hint: 'Team attack & defence boards below use live standings.',
          )
        else
          ...List.generate(scorers.length, (i) {
            final sc = scorers[i];
            return _ScorerRow(
              rank: sc.rank > 0 ? sc.rank : i + 1,
              playerName: sc.playerName,
              team: sc.team,
              goals: sc.goals,
              assists: sc.assists,
              played: sc.played,
            );
          }),
        if (attack.isNotEmpty) ...[
          SizedBox(height: 18),
          _StatsSectionHeader(
            title: 'Best Attack',
            subtitle: 'Goals scored · from standings',
            icon: Icons.local_fire_department_rounded,
          ),
          SizedBox(height: 8),
          ...List.generate(attack.length, (i) {
            final row = attack[i];
            return _TeamStatRow(
              rank: i + 1,
              team: row.team,
              value: '${row.goalsFor}',
              unit: 'GF',
              accent: AppColors.accent,
            );
          }),
        ],
        if (defence.isNotEmpty) ...[
          SizedBox(height: 18),
          _StatsSectionHeader(
            title: 'Best Defence',
            subtitle: 'Goals conceded · from standings',
            icon: Icons.shield_rounded,
          ),
          SizedBox(height: 8),
          ...List.generate(defence.length, (i) {
            final row = defence[i];
            return _TeamStatRow(
              rank: i + 1,
              team: row.team,
              value: '${row.goalsAgainst}',
              unit: 'GA',
              accent: AppColors.ethioEmerald,
            );
          }),
        ],
      ],
    );
  }
}

class _StatsSectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;

  const _StatsSectionHeader({
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: AppColors.accent.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: AppColors.accent),
        ),
        SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.outfit(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                ),
              ),
              Text(
                subtitle,
                style: GoogleFonts.outfit(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _StatsEmptyCard extends StatelessWidget {
  final String message;
  final String hint;
  const _StatsEmptyCard({required this.message, required this.hint});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surfaceElevated,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.surfaceBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            message,
            style: GoogleFonts.outfit(
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
              fontSize: 13.5,
            ),
          ),
          SizedBox(height: 4),
          Text(
            hint,
            style: GoogleFonts.outfit(
              fontWeight: FontWeight.w500,
              color: AppColors.textSecondary,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

class _ScorerRow extends StatelessWidget {
  final int rank;
  final String playerName;
  final FootballTeam team;
  final int goals;
  final int assists;
  final int played;

  const _ScorerRow({
    required this.rank,
    required this.playerName,
    required this.team,
    required this.goals,
    required this.assists,
    required this.played,
  });

  @override
  Widget build(BuildContext context) {
    final podium = rank <= 3;
    final rankColor = rank == 1
        ? AppColors.govHolidayGlow
        : rank == 2
            ? Color(0xFFCBD5E1)
            : rank == 3
                ? Color(0xFFD97706)
                : AppColors.textSecondary;

    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: podium
              ? rankColor.withValues(alpha: 0.45)
              : AppColors.surfaceBorder,
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 32,
            child: Container(
              width: 28,
              height: 28,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: podium
                    ? rankColor.withValues(alpha: 0.18)
                    : AppColors.surfaceElevated,
                border: Border.all(color: rankColor.withValues(alpha: 0.55)),
              ),
              child: Text(
                '$rank',
                style: GoogleFonts.outfit(
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  color: rankColor,
                ),
              ),
            ),
          ),
          SizedBox(width: 10),
          FootballLogo.team(team, size: 32),
          SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  playerName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.outfit(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                  ),
                ),
                Text(
                  [
                    team.name,
                    if (played > 0) '$played apps',
                    if (assists > 0) '$assists assists',
                  ].join(' · '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: GoogleFonts.outfit(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.accent.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              '$goals',
              style: GoogleFonts.outfit(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: AppColors.accent,
              ),
            ),
          ),
          SizedBox(width: 4),
          Text(
            'G',
            style: GoogleFonts.outfit(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

class _TeamStatRow extends StatelessWidget {
  final int rank;
  final FootballTeam team;
  final String value;
  final String unit;
  final Color accent;

  const _TeamStatRow({
    required this.rank,
    required this.team,
    required this.value,
    required this.unit,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.surfaceBorder),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 28,
            child: Text(
              '$rank',
              textAlign: TextAlign.center,
              style: GoogleFonts.outfit(
                fontWeight: FontWeight.w900,
                color: AppColors.textSecondary,
              ),
            ),
          ),
          FootballLogo.team(team, size: 28),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              team.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: GoogleFonts.outfit(
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          Text(
            value,
            style: GoogleFonts.outfit(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: accent,
            ),
          ),
          SizedBox(width: 4),
          Text(
            unit,
            style: GoogleFonts.outfit(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}

/// Professional spinning refresh control that stays active while APIs load.
class _ActiveRefreshButton extends StatefulWidget {
  final bool refreshing;
  final DateTime? lastUpdated;
  final Future<void> Function() onRefresh;

  const _ActiveRefreshButton({
    required this.refreshing,
    required this.onRefresh,
    this.lastUpdated,
  });

  @override
  State<_ActiveRefreshButton> createState() => _ActiveRefreshButtonState();
}

class _ActiveRefreshButtonState extends State<_ActiveRefreshButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spin;

  @override
  void initState() {
    super.initState();
    _spin = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    if (widget.refreshing) _spin.repeat();
  }

  @override
  void didUpdateWidget(covariant _ActiveRefreshButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.refreshing && !_spin.isAnimating) {
      _spin.repeat();
    } else if (!widget.refreshing && _spin.isAnimating) {
      _spin.stop();
      _spin.reset();
    }
  }

  @override
  void dispose() {
    _spin.dispose();
    super.dispose();
  }

  String get _tooltip {
    if (widget.refreshing) return 'Refreshing live APIs…';
    if (widget.lastUpdated == null) return 'Refresh live football data';
    final s = DateTime.now().difference(widget.lastUpdated!).inSeconds;
    if (s < 60) return 'Updated ${s}s ago · tap to refresh';
    final m = s ~/ 60;
    return 'Updated ${m}m ago · tap to refresh';
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: _tooltip,
      onPressed: widget.refreshing ? null : () => widget.onRefresh(),
      icon: RotationTransition(
        turns: _spin,
        child: Icon(
          Icons.refresh_rounded,
          color: widget.refreshing
              ? AppColors.accent
              : AppColors.textPrimary,
        ),
      ),
    );
  }
}
