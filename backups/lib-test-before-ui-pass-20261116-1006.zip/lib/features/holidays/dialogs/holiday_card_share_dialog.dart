import 'package:material_ui/material_ui.dart';
import '../../../../core/calendar/ethiopian_calendar_engine.dart';
import '../../../../core/calendar/ethiopian_date.dart';
import '../../../../core/localization/app_language.dart';
import '../../../../core/localization/locale_strings.dart';
import '../../../../core/utils/share_helper.dart';
import '../../shared/components/ethiocal_logo.dart';

class HolidayCardShareDialog extends StatefulWidget {
  final EthiopianDate currentDate;
  final AppLanguage currentLanguage;
  final VoidCallback onDismiss;

  const HolidayCardShareDialog({
    super.key,
    required this.currentDate,
    this.currentLanguage = AppLanguage.amharic,
    required this.onDismiss,
  });

  @override
  State<HolidayCardShareDialog> createState() => _HolidayCardShareDialogState();
}

class _HolidayCardShareDialogState extends State<HolidayCardShareDialog> {
  late TextEditingController _messageController;
  int _selectedGradient = 0;

  final List<List<Color>> _gradients = [
    [const Color(0xFF06221A), const Color(0xFF0B1526), const Color(0xFF060C16)], // Imperial Emerald
    [const Color(0xFF1E1B4B), const Color(0xFF312E81), const Color(0xFF0F172A)], // Royal Indigo
    [const Color(0xFF450A0A), const Color(0xFF7F1D1D), const Color(0xFF1C1917)], // Axum Crimson
    [const Color(0xFF431407), const Color(0xFF7C2D12), const Color(0xFF1C1917)], // Simien Terracotta
    [const Color(0xFF0F2027), const Color(0xFF203A43), const Color(0xFF2C5364)], // Midnight Cyan
  ];

  @override
  void initState() {
    super.initState();
    _messageController = TextEditingController(
      text: 'እንኳን ለዚህ የተቀደሰ ቀን በሰላም አደረሳችሁ! መልካም ዕለት ይሁንላችሁ! 🇪🇹✨',
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dow = EthiopianCalendarEngine.getDayOfWeek(widget.currentDate);
    final gDate = EthiopianCalendarEngine.toGregorian(widget.currentDate);
    final monthName = LocaleStrings.getMonthName(widget.currentDate.month, widget.currentLanguage);
    final weekdayName = LocaleStrings.getWeekdayLong(dow, widget.currentLanguage);

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      backgroundColor: theme.colorScheme.surface,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('የበዓል እና የዕለት ካርድ (Greeting Card)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  IconButton(icon: const Icon(Icons.close), onPressed: widget.onDismiss),
                ],
              ),
              const SizedBox(height: 14),

              // Card Preview Container
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: _gradients[_selectedGradient],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFFF59E0B), width: 1.5),
                  boxShadow: const [
                    BoxShadow(color: Colors.black38, blurRadius: 10, offset: Offset(0, 4)),
                  ],
                ),
                child: Column(
                  children: [
                    // Top Logo & Badge
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const EthioCalLogo(size: 32),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF59E0B).withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: const Color(0xFFF59E0B), width: 1),
                          ),
                          child: const Text(
                            'ኢትዮጵያ • Zemen: Ethiopian Calendar',
                            style: TextStyle(color: Color(0xFFF59E0B), fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),

                    // Date display
                    Text(
                      '${widget.currentDate.day}',
                      style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w900, color: Color(0xFFF59E0B)),
                    ),
                    Text(
                      '$monthName ${widget.currentDate.year} ዓ.ም',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '$weekdayName • ${gDate.day}/${gDate.month}/${gDate.year} G.C.',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                    const SizedBox(height: 14),

                    // Message inside card
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _messageController.text,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Gradient Selector
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(_gradients.length, (i) {
                  final isSelected = _selectedGradient == i;
                  return InkWell(
                    onTap: () => setState(() => _selectedGradient = i),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: _gradients[i]),
                        shape: BoxShape.circle,
                        border: isSelected ? Border.all(color: Colors.white, width: 2.5) : null,
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 14),

              // Edit Blessing Message
              TextField(
                controller: _messageController,
                maxLines: 2,
                onChanged: (val) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'የመልካም ምኞት ቃል ያርትዑ (Custom Message)',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),

              // Share Button
              FilledButton.icon(
                icon: const Icon(Icons.share, size: 18),
                label: const Text('ካርዱን አጋራ (Share Card)'),
                onPressed: () {
                  final shareText = '✨ ${widget.currentDate.day} $monthName ${widget.currentDate.year} ዓ.ም ✨\n'
                      '($weekdayName • ${gDate.day}/${gDate.month}/${gDate.year} G.C.)\n\n'
                      '«${_messageController.text.trim()}»\n\n'
                      '— ከኢትዮጵያ ካላንደር መተግበሪያ (Zemen: Ethiopian Calendar)';
                  ShareHelper.share(shareText);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
