import 'package:material_ui/material_ui.dart';
import '../../../../core/calendar/ethiopian_calendar_engine.dart';
import '../../../../core/calendar/ethiopian_date.dart';
import '../../../../core/holidays/holiday_engine.dart';
import '../../../../core/localization/app_language.dart';
import '../../../../core/localization/locale_strings.dart';
import '../../../../core/utils/share_helper.dart';

class HolidayDetailDialog extends StatelessWidget {
  final Holiday holiday;
  final AppLanguage currentLang;
  final EthiopianDate todayEth;
  final VoidCallback onDismiss;
  final ValueChanged<Holiday> onAddToEvents;
  final ValueChanged<Holiday> onShareCard;
  final ValueChanged<EthiopianDate>? onNavigateToCalendar;

  const HolidayDetailDialog({
    super.key,
    required this.holiday,
    this.currentLang = AppLanguage.amharic,
    required this.todayEth,
    required this.onDismiss,
    required this.onAddToEvents,
    required this.onShareCard,
    this.onNavigateToCalendar,
  });

  Color _getTypeColor(HolidayType type) {
    switch (type) {
      case HolidayType.nationalPublic:
        return const Color(0xFFEF4444);
      case HolidayType.orthodoxMajor:
      case HolidayType.orthodoxMovable:
        return const Color(0xFFF59E0B);
      case HolidayType.orthodoxFasting:
        return const Color(0xFF10B981);
      case HolidayType.islamic:
        return const Color(0xFF059669);
      case HolidayType.culturalRegional:
        return const Color(0xFF8B5CF6);
      case HolidayType.monthlySaint:
        return const Color(0xFF3B82F6);
    }
  }

  String _getTypeLabel(HolidayType type) {
    switch (type) {
      case HolidayType.nationalPublic:
        return 'National Public Holiday (የሕዝብ በዓል)';
      case HolidayType.orthodoxMajor:
        return 'Orthodox Major Feast (የተዋሕዶ በዓል)';
      case HolidayType.orthodoxMovable:
        return 'Movable Orthodox Feast (ተንቀሳቃሽ በዓል)';
      case HolidayType.orthodoxFasting:
        return 'Orthodox Canonical Fast (የጾም ወቅት)';
      case HolidayType.islamic:
        return 'Islamic Observance (የእስልምና በዓል)';
      case HolidayType.culturalRegional:
        return 'Cultural Heritage Festival (ባህላዊ በዓል)';
      case HolidayType.monthlySaint:
        return 'Monthly Saint Commemoration (የወር ጽላት)';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dow = EthiopianCalendarEngine.getDayOfWeek(holiday.ethiopianDate);
    final gDate = EthiopianCalendarEngine.toGregorian(holiday.ethiopianDate);
    final daysUntil = holiday.ethiopianDate >= todayEth
        ? EthiopianCalendarEngine.daysBetween(todayEth, holiday.ethiopianDate)
        : -EthiopianCalendarEngine.daysBetween(holiday.ethiopianDate, todayEth);

    final typeColor = _getTypeColor(holiday.type);
    final monthName = LocaleStrings.getMonthName(holiday.ethiopianDate.month, currentLang);
    final weekdayName = LocaleStrings.getWeekdayLong(dow, currentLang);

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      backgroundColor: theme.colorScheme.surface,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Header Row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: typeColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      _getTypeLabel(holiday.type),
                      style: TextStyle(
                        color: typeColor,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: onDismiss,
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Title Display
              Text(
                holiday.titleAmharic,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Text(
                holiday.titleEnglish,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: theme.colorScheme.primary,
                ),
              ),
              const SizedBox(height: 14),

              // Date & Countdown Badges
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '$monthName ${holiday.ethiopianDate.day}፣ ${holiday.ethiopianDate.year} ዓ.ም',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        Text(
                          '$weekdayName • ${gDate.day}/${gDate.month}/${gDate.year} G.C.',
                          style: TextStyle(color: theme.colorScheme.onSurfaceVariant, fontSize: 11),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        daysUntil == 0
                            ? 'ዛሬ (Today!)'
                            : daysUntil > 0
                                ? '$daysUntil ቀናት ቀሩ'
                                : '${-daysUntil} ቀናት አልፈዋል',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Description
              const Text('ስለ በዓሉ ዝርዝር (About Holiday):', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              const SizedBox(height: 6),
              Text(
                holiday.description,
                style: TextStyle(
                  fontSize: 13,
                  height: 1.5,
                  color: theme.colorScheme.onSurface,
                ),
              ),
              const SizedBox(height: 18),

              // Actions Row
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  OutlinedButton.icon(
                    icon: const Icon(Icons.notifications_active, size: 16),
                    label: const Text('ማሳሰቢያ አዘጋጅ'),
                    onPressed: () {
                      onAddToEvents(holiday);
                      onDismiss();
                    },
                  ),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.card_giftcard, size: 16),
                    label: const Text('ካርድ አጋራ'),
                    onPressed: () {
                      onShareCard(holiday);
                      onDismiss();
                    },
                  ),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.calendar_month, size: 16),
                    label: const Text('በካላንደር እይ'),
                    onPressed: () {
                      if (onNavigateToCalendar != null) {
                        onNavigateToCalendar!(holiday.ethiopianDate);
                      }
                      onDismiss();
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.share, size: 20),
                    tooltip: 'ጽሑፉን አጋራ',
                    onPressed: () {
                      ShareHelper.share(
                        '✨ ${holiday.titleAmharic} (${holiday.titleEnglish})\n'
                        '📅 $monthName ${holiday.ethiopianDate.day}፣ ${holiday.ethiopianDate.year} ዓ.ም\n'
                        '${holiday.description}\n\n'
                        '— ከኢትዮጵያ ካላንደር (Zemen: Ethiopian Calendar)',
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
