import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/calendar/ethiopian_calendar_engine.dart';
import '../../core/calendar/ethiopian_date.dart';
import '../../core/holidays/holiday_engine.dart';
import '../../data/models/event_entity.dart';
import '../shared/components/app_surface.dart';
import '../shared/providers.dart';
import 'dialogs/holiday_card_share_dialog.dart';
import 'dialogs/holiday_detail_dialog.dart';
import 'dialogs/set_holiday_reminder_dialog.dart';
import 'tabs/annual_holidays_tab.dart';
import 'tabs/fasting_guide_tab.dart';
import 'tabs/greeting_card_studio_tab.dart';
import 'tabs/monthly_saints_tab.dart';

class HolidaysScreen extends ConsumerStatefulWidget {
  final ValueChanged<EthiopianDate>? onNavigateToCalendar;

  const HolidaysScreen({super.key, this.onNavigateToCalendar});

  @override
  ConsumerState<HolidaysScreen> createState() => _HolidaysScreenState();
}

class _HolidaysScreenState extends ConsumerState<HolidaysScreen> {
  int _selectedTab = 0;
  int _selectedYear = 2017;

  @override
  void initState() {
    super.initState();
    _selectedYear = EthiopianCalendarEngine.todayEthiopian().year;
  }

  void _showHolidayDetail(Holiday h, EthiopianDate todayEth) {
    final currentLang = ref.read(currentAppLanguageProvider);
    showDialog(
      context: context,
      builder: (_) => HolidayDetailDialog(
        holiday: h,
        currentLang: currentLang,
        todayEth: todayEth,
        onDismiss: () => Navigator.of(context).pop(),
        onAddToEvents: (holiday) => _showSetReminderDialog(holiday),
        onShareCard: (holiday) {
          setState(() => _selectedTab = 3);
        },
        onNavigateToCalendar: widget.onNavigateToCalendar,
      ),
    );
  }

  void _showSetReminderDialog(Holiday h) {
    final currentLang = ref.read(currentAppLanguageProvider);
    final allEvents = ref.read(eventsNotifierProvider).value ?? [];
    final existing = allEvents.firstWhere(
      (e) =>
          e.ethiopianYear == h.ethiopianDate.year &&
          e.ethiopianMonth == h.ethiopianDate.month &&
          e.ethiopianDay == h.ethiopianDate.day &&
          (e.title.contains(h.titleEnglish) || e.title.contains(h.titleAmharic)),
      orElse: () => EventEntity.empty(),
    );

    showDialog(
      context: context,
      builder: (_) => SetHolidayReminderDialog(
        holiday: h,
        existingEvent: existing.id != 0 ? existing : null,
        currentLang: currentLang,
        onDismiss: () => Navigator.of(context).pop(),
        onSaveReminder: (alertHour, alertMinute, remindOnEve, reminderMinutesBefore) async {
          final targetDate = remindOnEve
              ? (h.ethiopianDate.day > 1
                  ? EthiopianDate(h.ethiopianDate.year, h.ethiopianDate.month, h.ethiopianDate.day - 1)
                  : EthiopianDate(h.ethiopianDate.year, h.ethiopianDate.month == 1 ? 13 : h.ethiopianDate.month - 1, 30))
              : h.ethiopianDate;

          final gDate = EthiopianCalendarEngine.toGregorian(targetDate);
          final eveSuffix = remindOnEve ? ' [ዋዜማ / Eve]' : '';
          final event = EventEntity(
            id: existing.id != 0 ? existing.id : 0,
            title: '${h.titleAmharic} (${h.titleEnglish})$eveSuffix',
            description: h.description,
            category: 'HOLIDAY',
            ethiopianYear: targetDate.year,
            ethiopianMonth: targetDate.month,
            ethiopianDay: targetDate.day,
            gregorianYear: gDate.year,
            gregorianMonth: gDate.month,
            gregorianDay: gDate.day,
            hour: alertHour,
            minute: alertMinute,
            isAllDay: true,
            recurrence: 'NONE',
            reminderMinutesBefore: reminderMinutesBefore,
            colorHex: h.isPublicHoliday ? '#EF4444' : '#F59E0B',
            createdAt: DateTime.now().millisecondsSinceEpoch,
          );
          await ref.read(eventsNotifierProvider.notifier).saveEvent(event);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('የበዓል ማሳሰቢያ ተመዝግቧል')),
            );
          }
        },
        onDeleteReminder: () async {
          if (existing.id != 0) {
            await ref.read(eventsNotifierProvider.notifier).deleteEvent(existing.id);
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('ማሳሰቢያው ተሰርዟል')),
              );
            }
          }
        },
      ),
    );
  }

  void _showCardShareDialog(Holiday h) {
    final currentLang = ref.read(currentAppLanguageProvider);
    showDialog(
      context: context,
      builder: (_) => HolidayCardShareDialog(
        currentDate: h.ethiopianDate,
        currentLanguage: currentLang,
        onDismiss: () => Navigator.of(context).pop(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final todayEth = ref.watch(todayEthiopianProvider);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AppAtmosphere(
        child: Column(
          children: [
            TabBarHeader(
              selectedTab: _selectedTab,
              onTabSelected: (index) => setState(() => _selectedTab = index),
            ),
            Divider(height: 1, color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3)),
            Expanded(
              child: IndexedStack(
                index: _selectedTab,
                children: [
                  AnnualHolidaysTab(
                    selectedYear: _selectedYear,
                    onYearChange: (y) => setState(() => _selectedYear = y),
                    onSelectHolidayForDetail: (h) => _showHolidayDetail(h, todayEth),
                    onOpenReminder: (h) => _showSetReminderDialog(h),
                    onOpenCardShare: (h) => _showCardShareDialog(h),
                    onNavigateToCalendar: widget.onNavigateToCalendar,
                  ),
                  FastingGuideTab(selectedYear: _selectedYear),
                  MonthlySaintsTab(onNavigateToCalendar: widget.onNavigateToCalendar),
                  const GreetingCardStudioTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TabBarHeader extends StatelessWidget {
  final int selectedTab;
  final ValueChanged<int> onTabSelected;

  const TabBarHeader({
    super.key,
    required this.selectedTab,
    required this.onTabSelected,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final tabs = [
      {'title': 'በዓላት (Holidays)', 'icon': Icons.event},
      {'title': 'አጽዋማት (Fasting)', 'icon': Icons.restaurant_menu},
      {'title': 'ጽላቶች (Saints)', 'icon': Icons.church},
      {'title': 'ካርድ (Card)', 'icon': Icons.card_giftcard},
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: List.generate(tabs.length, (i) {
          final isSelected = selectedTab == i;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => onTabSelected(i),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected
                      ? theme.colorScheme.primary
                      : theme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: isSelected
                        ? theme.colorScheme.primary
                        : theme.colorScheme.outline.withValues(alpha: 0.45),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      tabs[i]['icon'] as IconData,
                      size: 16,
                      color: isSelected ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      tabs[i]['title'] as String,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                        color: isSelected ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
