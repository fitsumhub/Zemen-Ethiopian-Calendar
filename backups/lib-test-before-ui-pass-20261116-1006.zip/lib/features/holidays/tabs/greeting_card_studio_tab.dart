import 'package:material_ui/material_ui.dart';
import '../../../../core/ads/ad_frequency_controller.dart';
import '../../../../core/ads/interstitial_ad_manager.dart';
import '../../../../core/calendar/ethiopian_calendar_engine.dart';
import '../../../../core/holidays/holiday_engine.dart';
import '../../../../core/utils/share_helper.dart';
import '../../shared/components/ethiocal_logo.dart';

class GreetingCardStudioTab extends StatefulWidget {
  final Holiday? initialHoliday;

  const GreetingCardStudioTab({super.key, this.initialHoliday});

  @override
  State<GreetingCardStudioTab> createState() => _GreetingCardStudioTabState();
}

class _GreetingCardStudioTabState extends State<GreetingCardStudioTab> {
  int _selectedPreset = 0;
  int _selectedGradient = 0;
  late TextEditingController _recipientController;
  late TextEditingController _messageController;

  final List<Map<String, dynamic>> _presets = [
    {
      'titleAmharic': 'መልካም አዲስ ዓመት (እንቁጣጣሽ)',
      'titleEnglish': 'Happy Ethiopian New Year (Enkutatash)',
      'defaultMessage': 'እንኳን ከአሮጌው ዓመት ወደ አዲሱ ዓመት በሰላም አሸጋገራችሁ! አዲሱ ዓመት የሰላም፣ የፍቅርና የበረከት ይሁንላችሁ! 🌼🇪🇹',
    },
    {
      'titleAmharic': 'መልካም የመስቀል በዓል',
      'titleEnglish': 'Happy Meskel Feast',
      'defaultMessage': 'እንኳን ለብርሃነ መስቀሉ በዓል በሰላም አደረሳችሁ! የመስቀሉ ፍቅርና በረከት ከሁላችን ጋር ይሁን! 🔥✨',
    },
    {
      'titleAmharic': 'መልካም የገና በዓል',
      'titleEnglish': 'Merry Ethiopian Christmas (Genna)',
      'defaultMessage': 'እንኳን ለጌታችን ለመድኃኒታችን ለኢየሱስ ክርስቶስ የልደት በዓል በሰላም አደረሳችሁ! መልካም የገና በዓል! 🎄✨',
    },
    {
      'titleAmharic': 'መልካም የጥምቀት በዓል',
      'titleEnglish': 'Happy Timket (Epiphany)',
      'defaultMessage': 'እንኳን ለብርሃነ ጥምቀቱ በዓል በሰላም አደረሳችሁ! የጥምቀቱ በረከትና ረድኤት አይለያችሁ! 🕊️💧',
    },
    {
      'titleAmharic': 'መልካም የትንሣኤ በዓል (ፋሲካ)',
      'titleEnglish': 'Happy Easter (Fasika)',
      'defaultMessage': 'እንኳን ለብርሃነ ትንሣኤው በሰላም አደረሳችሁ! ክርስቶስ ተንሥአ እሙታን! በዓሉ የሰላምና የደስታ ይሁንላችሁ! 🕯️✨',
    },
    {
      'titleAmharic': 'ዒድ ሙባረክ (ዒድ አል-ፊጥር)',
      'titleEnglish': 'Eid Mubarak (Eid al-Fitr)',
      'defaultMessage': 'እንኳን ለዒድ አል-ፊጥር በዓል በሰላም አደረሳችሁ! ኩሉ ዓም ወአንቱም ቢኸይር! ዒድ ሙባረክ! 🌙✨',
    },
    {
      'titleAmharic': 'ዒድ ሙባረክ (ዒድ አል-አድሐ)',
      'titleEnglish': 'Eid Mubarak (Eid al-Adha)',
      'defaultMessage': 'እንኳን ለዒድ አል-አድሐ (ዐረፋ) በዓል በሰላም አደረሳችሁ! መልካም የበዓል ጊዜ ይሁንላችሁ! 🐑✨',
    },
    {
      'titleAmharic': 'ባጋም ገዳ ዒሬቻ ገሴስቱ!',
      'titleEnglish': 'Happy Irreecha Festival',
      'defaultMessage': 'እንኳን ለምስጋናው እና ለእርቅ በዓል ለዒሬቻ በሰላም አደረሳችሁ! ሆራ ፊንፊኔ እና ሆራ ሀርሰዲ በረከት ይሁንልን! 🌾🌳',
    },
  ];

  final List<List<Color>> _gradientThemes = [
    [const Color(0xFF1E1B4B), const Color(0xFF312E81), const Color(0xFF0F172A)], // Imperial Indigo
    [const Color(0xFF06221A), const Color(0xFF0B1526), const Color(0xFF060C16)], // Emerald Gold
    [const Color(0xFF450A0A), const Color(0xFF7F1D1D), const Color(0xFF1C1917)], // Demera Crimson
    [const Color(0xFF451A03), const Color(0xFF78350F), const Color(0xFF1C1917)], // Adey Yellow
    [const Color(0xFF0F2027), const Color(0xFF203A43), const Color(0xFF2C5364)], // Midnight Cyan
  ];

  @override
  void initState() {
    super.initState();
    _recipientController = TextEditingController(text: 'ለሁሉም ወዳጅ ዘመዶቼ');
    _messageController = TextEditingController(
      text: _presets[_selectedPreset]['defaultMessage'] as String,
    );

    if (widget.initialHoliday != null) {
      for (int i = 0; i < _presets.length; i++) {
        if (widget.initialHoliday!.titleAmharic.contains(_presets[i]['titleAmharic'].toString().split(' ')[1])) {
          _selectedPreset = i;
          _messageController.text = _presets[i]['defaultMessage'] as String;
          break;
        }
      }
    }
  }

  @override
  void dispose() {
    _recipientController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final activePreset = _presets[_selectedPreset];
    final todayEth = EthiopianCalendarEngine.todayEthiopian();

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      children: [
        // Presets Horizontal Selector
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: List.generate(_presets.length, (i) {
              final isSelected = _selectedPreset == i;
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(
                  label: Text(_presets[i]['titleAmharic'] as String, style: const TextStyle(fontSize: 11)),
                  selected: isSelected,
                  onSelected: (val) {
                    setState(() {
                      _selectedPreset = i;
                      _messageController.text = _presets[i]['defaultMessage'] as String;
                    });
                  },
                ),
              );
            }),
          ),
        ),
        const SizedBox(height: 14),

        // Live Rendered Card Preview
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: _gradientThemes[_selectedGradient],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFF59E0B), width: 1.5),
            boxShadow: const [
              BoxShadow(color: Colors.black45, blurRadius: 10, offset: Offset(0, 4)),
            ],
          ),
          child: Column(
            children: [
              // Logo & Tricolor tag
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const EthioCalLogo(size: 34),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF59E0B).withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFFF59E0B), width: 1),
                    ),
                    child: Text(
                      '${todayEth.year} ዓ.ም • Zemen: Ethiopian Calendar',
                      style: const TextStyle(color: Color(0xFFF59E0B), fontSize: 10, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),

              // Holiday Main Greeting Title
              Text(
                activePreset['titleAmharic'] as String,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFFF59E0B),
                ),
              ),
              Text(
                activePreset['titleEnglish'] as String,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.white70),
              ),
              const SizedBox(height: 14),

              // Recipient banner
              if (_recipientController.text.isNotEmpty)
                Text(
                  'ለ: ${_recipientController.text}',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                ),
              const SizedBox(height: 10),

              // Message Body
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.35),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(
                  _messageController.text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 13, height: 1.5),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // Color Themes
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_gradientThemes.length, (i) {
            final isSelected = _selectedGradient == i;
            return InkWell(
              onTap: () => setState(() => _selectedGradient = i),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 6),
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: _gradientThemes[i]),
                  shape: BoxShape.circle,
                  border: isSelected ? Border.all(color: Colors.white, width: 2.5) : null,
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 14),

        // Recipient text field
        TextField(
          controller: _recipientController,
          onChanged: (val) => setState(() {}),
          decoration: const InputDecoration(
            labelText: 'ተቀባይ (Recipient)',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 10),

        // Message text field
        TextField(
          controller: _messageController,
          maxLines: 2,
          onChanged: (val) => setState(() {}),
          decoration: const InputDecoration(
            labelText: 'የመልካም ምኞት ቃል (Blessing Message)',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 16),

        // Share Card Button
        FilledButton.icon(
          icon: const Icon(Icons.share),
          label: const Text('የበዓል ካርዱን አጋራ (Share Greeting Card)'),
          onPressed: () {
            final shareText = '✨ ${activePreset['titleAmharic']} ✨\n'
                '(${activePreset['titleEnglish']})\n\n'
                'ለ: ${_recipientController.text}\n\n'
                '«${_messageController.text.trim()}»\n\n'
                '— ከኢትዮጵያ ካላንደር መተግበሪያ (Zemen: Ethiopian Calendar)';
            ShareHelper.share(shareText);
            AdFrequencyController.instance.recordUserAction('share_holiday_card');
            // Natural transition point: evaluate policy cooldown before showing
            InterstitialAdManager.instance.showIfAllowed(
              placement: 'share_holiday_card_transition',
            );
          },
        ),
      ],
    );
  }
}
