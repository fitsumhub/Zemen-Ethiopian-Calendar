import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:timezone/data/latest.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../../data/models/event_entity.dart';

/// Flutter port of Kotlin [NotificationScheduler].
/// Schedules local reminders for EthioCal events.
class NotificationScheduler {
  static const String channelId = 'ethiocal_reminders_channel';
  static const String channelName = 'Ethiopian Calendar Reminders';
  static const String channelDescription =
      'Notifications for Ethiopian Calendar events, tasks, and holiday reminders';

  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;

  static Future<void> initialize() async {
    if (_initialized) return;

    tz_data.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Africa/Addis_Ababa'));

    const androidSettings =
        AndroidInitializationSettings('@drawable/ic_notification');
    const iosSettings = DarwinInitializationSettings();
    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(settings: settings);

    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.createNotificationChannel(
      const AndroidNotificationChannel(
        channelId,
        channelName,
        description: channelDescription,
        importance: Importance.high,
        enableVibration: true,
        playSound: true,
      ),
    );

    _initialized = true;
  }

  static Future<bool> requestPermissions() async {
    if (defaultTargetPlatform == TargetPlatform.android) {
      final notif = await Permission.notification.request();
      await Permission.scheduleExactAlarm.request();
      return notif.isGranted;
    }
    return true;
  }

  static int notificationIdFor(int eventId) {
    final id = eventId & 0x7FFFFFFF;
    return id == 0 ? 1001 : id;
  }

  /// Next trigger time for an event, or null if reminders are disabled / completed.
  static DateTime? calculateNextTriggerTime(EventEntity event, {DateTime? now}) {
    if (event.reminderMinutesBefore < 0 || event.isCompleted) return null;

    final nowLocal = now ?? DateTime.now();
    // All-day reminders fire at 08:00 local; timed events use their clock time.
    final hour = event.isAllDay ? 8 : event.hour.clamp(0, 23);
    final minute = event.isAllDay ? 0 : event.minute.clamp(0, 59);
    final offset = Duration(minutes: event.reminderMinutesBefore);

    DateTime candidate = DateTime(
      event.gregorianYear,
      event.gregorianMonth,
      event.gregorianDay,
      hour,
      minute,
    ).subtract(offset);

    switch (event.recurrence) {
      case 'DAILY':
        while (!candidate.isAfter(nowLocal)) {
          candidate = candidate.add(const Duration(days: 1));
        }
        break;
      case 'WEEKLY':
        while (!candidate.isAfter(nowLocal)) {
          candidate = candidate.add(const Duration(days: 7));
        }
        break;
      case 'YEARLY_ETHIOPIAN':
      case 'YEARLY_GREGORIAN':
        while (!candidate.isAfter(nowLocal)) {
          candidate = DateTime(
            candidate.year + 1,
            candidate.month,
            candidate.day,
            candidate.hour,
            candidate.minute,
          );
        }
        break;
      case 'MONTHLY_ETHIOPIAN':
      case 'MONTHLY_GREGORIAN':
        while (!candidate.isAfter(nowLocal)) {
          final month = candidate.month == 12 ? 1 : candidate.month + 1;
          final year =
              candidate.month == 12 ? candidate.year + 1 : candidate.year;
          candidate = DateTime(
            year,
            month,
            candidate.day,
            candidate.hour,
            candidate.minute,
          );
        }
        break;
      default:
        if (!candidate.isAfter(nowLocal)) return null;
    }
    return candidate;
  }

  static Future<void> scheduleEventReminder(EventEntity event) async {
    if (!_initialized) await initialize();
    if (event.id <= 0) return;

    final trigger = calculateNextTriggerTime(event);
    if (trigger == null) {
      await cancelEventReminder(event.id);
      return;
    }

    final tzTrigger = tz.TZDateTime.from(trigger, tz.local);
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        channelName,
        channelDescription: channelDescription,
        importance: Importance.high,
        priority: Priority.high,
        color: const Color(0xFFE6A817),
        styleInformation: BigTextStyleInformation(
          event.description.isEmpty ? event.title : event.description,
          contentTitle: event.title,
        ),
      ),
      iOS: const DarwinNotificationDetails(),
    );

    await _plugin.zonedSchedule(
      id: notificationIdFor(event.id),
      title: event.title,
      body: event.description.isEmpty ? 'Zemen reminder' : event.description,
      scheduledDate: tzTrigger,
      notificationDetails: details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      payload: 'event:${event.id}',
    );
  }

  static Future<void> cancelEventReminder(int eventId) async {
    if (!_initialized) await initialize();
    await _plugin.cancel(id: notificationIdFor(eventId));
  }

  static Future<void> cancelAllReminders() async {
    if (!_initialized) await initialize();
    await _plugin.cancelAll();
  }

  static Future<void> rescheduleAll(List<EventEntity> events) async {
    if (!_initialized) await initialize();
    await cancelAllReminders();
    for (final event in events) {
      await scheduleEventReminder(event);
    }
  }

  /// Immediate smoke-test notification (does not require a saved event).
  static Future<bool> showTestNotification() async {
    if (!_initialized) await initialize();
    final allowed = await requestPermissions();
    if (!allowed) return false;

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        channelName,
        channelDescription: channelDescription,
        importance: Importance.high,
        priority: Priority.high,
        color: Color(0xFFE6A817),
      ),
      iOS: DarwinNotificationDetails(),
    );

    await _plugin.show(
      id: 900001,
      title: 'Zemen: Ethiopian Calendar',
      body: 'Reminders are working. Your events can alert you on time.',
      notificationDetails: details,
      payload: 'test',
    );
    return true;
  }
}
