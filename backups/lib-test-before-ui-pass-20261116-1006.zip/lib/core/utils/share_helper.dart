import 'package:share_plus/share_plus.dart';

class ShareHelper {
  static void share(String text, {String? subject}) {
    // ignore: deprecated_member_use
    Share.share(text, subject: subject);
  }
}
