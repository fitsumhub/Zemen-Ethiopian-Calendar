import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../localization/app_language.dart';
import 'home_widget_engine.dart';

/// Persists live widget payload and talks to the Android AppWidget host.
class HomeWidgetSync {
  HomeWidgetSync._();

  static const _channel = MethodChannel('com.aistudio.ethiocal/home_widget');

  static const keyShowFasting = 'pref_widget_show_fasting';
  static const keyShowGeez = 'pref_widget_show_geez';
  static const keyShowSaint = 'pref_widget_show_saint';
  static const keySize = 'pref_widget_size';

  static bool get _isAndroid =>
      !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  static Future<HomeWidgetSnapshot> sync({
    required int styleIndex,
    AppLanguage lang = AppLanguage.amharic,
    bool? showFasting,
    bool? showGeez,
    bool? showSaint,
    String? size,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final fasting = showFasting ?? prefs.getBool(keyShowFasting) ?? true;
    final geez = showGeez ?? prefs.getBool(keyShowGeez) ?? true;
    final saint = showSaint ?? prefs.getBool(keyShowSaint) ?? true;
    final widgetSize = size ?? prefs.getString(keySize) ?? 'compact';

    final kind = HomeWidgetKind.values[styleIndex.clamp(0, 3)];
    final snapshot = HomeWidgetEngine.build(kind, lang: lang);
    final firstDay = prefs.getString('pref_first_day_week') ?? 'MONDAY';
    final map = HomeWidgetEngine.toPreferenceMap(
      snapshot,
      showFasting: fasting,
      showGeez: geez,
      showSaint: saint,
      size: widgetSize,
      firstDayOfWeek: firstDay,
    );
    for (final entry in map.entries) {
      await prefs.setString(entry.key, entry.value);
    }
    await prefs.setInt('pref_widget_style', styleIndex.clamp(0, 3));
    await prefs.setBool(keyShowFasting, fasting);
    await prefs.setBool(keyShowGeez, geez);
    await prefs.setBool(keyShowSaint, saint);
    await prefs.setString(keySize, widgetSize);

    if (_isAndroid) {
      try {
        await _channel.invokeMethod('updateWidgets');
      } catch (_) {}
    }
    return snapshot;
  }

  static Future<Map<String, Object>> loadOptions() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'showFasting': prefs.getBool(keyShowFasting) ?? true,
      'showGeez': prefs.getBool(keyShowGeez) ?? true,
      'showSaint': prefs.getBool(keyShowSaint) ?? true,
      'size': prefs.getString(keySize) ?? 'compact',
    };
  }

  static Future<String> requestPin() async {
    if (kIsWeb) return 'web_preview';
    if (!_isAndroid) return 'unsupported';
    try {
      final result = await _channel.invokeMethod<String>('requestPin');
      return result ?? 'unknown';
    } on PlatformException catch (e) {
      return e.code;
    } catch (_) {
      return 'error';
    }
  }

  static Future<bool> areWidgetsPinned() async {
    if (!_isAndroid) return false;
    try {
      final count = await _channel.invokeMethod<int>('widgetCount') ?? 0;
      return count > 0;
    } catch (_) {
      return false;
    }
  }
}
