/// Zemen brand constants — single source of truth for product naming.
class Brand {
  Brand._();

  static const String nameEn = 'Zemen';
  static const String nameAm = 'ዘመን';
  /// Launcher / MaterialApp / store-facing full product name.
  static const String displayName = 'Zemen: Ethiopian Calendar';
  static const String displayNameBilingual =
      'Zemen: Ethiopian Calendar · ዘመን';
  static const String shortName = 'Zemen';
  static const String tagline =
      'Your Time. Your Tradition. Your Calendar.';
  static const String productLine = 'Ethiopian Calendar';
  static const String logoAsset = 'assets/logo/zemen_logo.jpg';
  static const String shortDescription =
      'Zemen: Ethiopian Calendar — dual Ethiopian & Gregorian calendar. Your Time. Your Tradition. Your Calendar.';
}
