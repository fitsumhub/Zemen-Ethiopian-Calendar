import 'package:ethiocal/core/calendar/ethiopian_calendar_engine.dart';
import 'package:ethiocal/data/preferences/user_preferences_repository.dart';
import 'package:ethiocal/features/calendar/calendar_home_screen.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({
      'pref_onboarding_completed': true,
      'pref_first_day_of_week': 'SUNDAY',
      'pref_calendar_format': 'ETHIOPIAN',
      'pref_numeral_type': 'ARABIC',
      'pref_show_fasting': true,
      'pref_show_monthly_saints': true,
    });
    await UserPreferencesRepository.initialize();
  });

  Widget buildTestableScreen() {
    return const ProviderScope(
      child: MaterialApp(
        home: Scaffold(
          body: CalendarHomeScreen(),
        ),
      ),
    );
  }

  group('CalendarHomeScreen Redesign & Responsiveness Tests', () {
    testWidgets('Renders month grid, clean native view switcher, and removes useless English clutter', (tester) async {
      await tester.pumpWidget(buildTestableScreen());
      await tester.pumpAndSettle();

      // View mode buttons are clean native Amharic without English suffixes
      expect(find.text('ወር'), findsOneWidget);
      expect(find.text('ሳምንት'), findsOneWidget);
      expect(find.text('ዓመት'), findsOneWidget);
      expect(find.text('ዕለት'), findsOneWidget);

      // Verify that duplicate "ዘመነ ዘመነ" does NOT exist anywhere on screen
      expect(find.textContaining('ዘመነ ዘመነ'), findsNothing);

      // Legend items are present as modern pill badges
      expect(find.text('መንግሥት'), findsOneWidget);
      expect(find.text('ባሕረ ሐሳብ'), findsOneWidget);
      expect(find.text('ማስታወሻ'), findsOneWidget);
      expect(find.text('ጾም'), findsOneWidget);
      expect(find.text('እስላማዊ'), findsOneWidget);

      // Verify no "Islamic≈" with raw tilde appears
      expect(find.text('Islamic≈'), findsNothing);

      // Verify clean native events & notes header is present without useless EN clutter
      expect(find.text('የዕለቱ ማስታወሻዎች'), findsOneWidget);
      expect(find.text('አክል'), findsOneWidget);

      // Verify useless English labels have been completely removed
      expect(find.text('SELECTED DAY'), findsNothing);
      expect(find.textContaining('(Regular Day)'), findsNothing);
      expect(find.textContaining('(Events & Notes)'), findsNothing);
      expect(find.textContaining('(Add)'), findsNothing);
    });

    testWidgets('Selected Date Inspector shows hero ticket tile, saint, and fasting chips', (tester) async {
      await tester.pumpWidget(buildTestableScreen());
      await tester.pumpAndSettle();

      final today = EthiopianCalendarEngine.todayEthiopian();

      // Today's day number in the hero ticket badge
      expect(find.text('${today.day}'), findsAtLeastNWidgets(1));

      // Share button in inspector
      expect(find.byIcon(Icons.ios_share_rounded), findsWidgets);

      // Notes empty state with clean icon
      expect(find.byIcon(Icons.note_add_outlined), findsOneWidget);
    });

    testWidgets('Dynamic month grid eliminates redundant 6th row (4 up to 10) for 5-row months', (tester) async {
      await tester.pumpWidget(buildTestableScreen());
      await tester.pumpAndSettle();

      // Find the GridView inside PageView
      final gridFinder = find.byType(GridView);
      expect(gridFinder, findsWidgets);

      // Verify that the active GridView renders exactly 35 cells (5 rows of 7) for a 5-row month
      // rather than hardcoding 42 cells.
      final grids = tester.widgetList<GridView>(gridFinder);
      expect(grids.any((g) => (g.childrenDelegate as SliverChildBuilderDelegate).estimatedChildCount == 35), isTrue);
    });
  });
}
